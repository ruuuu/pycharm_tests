# -*- coding: utf-8 -*-

import os


import unittest
from appium import webdriver # все равно работает


import time




class ContactAndroidTests(unittest.TestCase):

    def setUp(self):
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'
        desired_caps['app'] = '/Users/rufina/Desktop/ContactManager.apk' # обязательно путь к файлу приложения надо надо указывать, иначе убдет ошибку выдавать


        desired_caps['appPackage'] = 'com.example.android.contactmanager'
        desired_caps['appActivity'] = '.ContactManager'


        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps) # bybwbfkbpbhe.n lhfqdth


    def tearDown(self):
        self.driver.quit()


    def select_type_phone(self, driver): # Домашний Рабочий мобильный Другой
       try:
            # выпадающий список
            type_phone = driver.find_element_by_id(
                "com.example.android.contactmanager:id/contactPhoneTypeSpinner")  # беремм по id(resourse-id)
            type_phone.click()

            type_phone_items = driver.find_elements_by_class_name(
                "android.widget.CheckedTextView")  # это спсиок itemov, из выпадающего спсика выбираем тип номера телевыона
            type_phone_items[1].click()  # выбираем Рабочий
       except TimeoutError:
           print("вреям вышло")




    def select_type_email(self, driver): # выбираем тип мейла

      try:
        # выпадающий список
        type_email = driver.find_element_by_id(
            "com.example.android.contactmanager:id/contactEmailTypeSpinner")  # берем по id(resourse-id)
        type_email.click()

        type_email_items = driver.find_elements_by_class_name(
            "android.widget.CheckedTextView")  #массив ,  из выпадающего спсика выбираем тип миейла
        if type_email_items[3].is_displayed():  # если item успел подгрузиться то кликаем
            type_email_items[3].click()  # выбираем Другой

      except TimeoutError:
         print("вреям выполнения истекло")



    def test_add_contacts(self):

        driver = self.driver
        try:
            time.sleep(3)
            #жмем кнопку Add Contact
            el = driver.find_element_by_class_name("android.widget.Button") # ищем по названию класса , назвагние класа android.widget.Button
            el.click()


            cantact_name= driver.find_element_by_id("com.example.android.contactmanager:id/contactNameEditText") # находим элемент по id(то есть recourse-id)
            if cantact_name.is_displayed(): # если поле видимое
                cantact_name.send_keys("User6")


            contact_phone= driver.find_element_by_id("com.example.android.contactmanager:id/contactPhoneEditText")# находим элемент по id( recourse-id)
            if contact_phone.is_displayed():# если поле видимое
                contact_phone.send_keys("87098222321")


            self.select_type_phone(driver) # вызов метода котрый выше

            contact_email = driver.find_element_by_id("com.example.android.contactmanager:id/contactEmailEditText")# находим элемент по id( recourse-id)
            contact_email.send_keys("jksgfakhh@yandex.ru")

            self.select_type_phone(driver)# вызов метода котрый выше



            save_but= driver.find_element_by_id("com.example.android.contactmanager:id/contactSaveButton")# находим элемент по id( recourse-id)
            save_but.click()
        except TimeoutError:
            print(" время вышло")
        #а можно так:
       #  textfields = self.driver.find_elements_by_class_name("android.widget.EditText") #  текстовое поле , списорк элементов у котрых класс = "android.widget.EditText"
       #  textfields[0].send_keys("testuser") # поле ContactName
       #  textfields[1].send_keys("88909876543") # поле Phone
       #  textfields[2].send_keys("fdjghsjghk@mail.ru")# поле ContacntEmail
       #
       #  self.driver.find_element_by_class_name("android.widget.Button").click() # кнопка Save
       #
       # # self.driver.find_element_by_android_uiautomator('new UiSelector().clickable(true)').click()
       #
       #  #self.driver.press_keycode(3)





if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(ContactAndroidTests)
    unittest.TextTestRunner(verbosity=2).run(suite)
