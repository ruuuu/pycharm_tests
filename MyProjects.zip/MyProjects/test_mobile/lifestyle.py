# -*- coding: utf-8 -*-

import os


import unittest
from appium import webdriver #
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec

import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


class Bon_ration(unittest.TestCase):

    def setUp(self):

        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'
        desired_caps['app'] = '/Users/rufina/Desktop/ru.lifestyle.apk' # обязательно путь к файлу приложения надо надо указывать, иначе убдет ошибку выдавать


        desired_caps['appPackage'] = 'ru.lifestyle'
        desired_caps['appActivity'] = 'ru.lifestyle.main.activity.MainActivity'


        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps) # bybwbfkbpbhe.n lhfqdth





    def test_companies(self): #

      # кнпока Пропустить
      propustu_button = self.driver.find_element_by_id("ru.lifestyle:id/skip")
      propustu_button.click()

      # поиск компании:

      # lupa = WebDriverWait(self.driver, 10).until(
      #     ec.presence_of_all_elements_located((By.CLASS_NAME, "android.widget.Button")))[2]  # иконка лупы, 2=instance
      # lupa.click()

      time.sleep(7)
      # нажимаем на иконку Лупа:
      el1 =  WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
          "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.Button[2]")))
      el1.click()

      time.sleep(1)
      el2 =  WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
          "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.view.View[2]/android.view.View[2]/android.widget.EditText")))
      el2.send_keys("Top Food Market")

      time.sleep(1)
      podskazka  = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
          "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.view.View[2]/android.view.View[3]/android.view.View")))
      podskazka.click()


      #на сранцие компании:
      vkladka1 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
          "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.widget.Button[2]")))
      #self.driver.send_keys(Keys.PAGE_DOWN)

      time.sleep(1)
      vkladka1.click()

      time.sleep(1)
      vkladka2 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.widget.Button[3]")))
      vkladka2.click()

      time.sleep(2)


      # companies_cards = WebDriverWait(self.driver, 10).until(
      #     ec.presence_of_all_elements_located((By.CLASS_NAME, "android.view.View")))
      #
      # time.sleep(3)
      # companies_cards[3].click() # выбрали компанию

      time.sleep(5)




    def tearDown(self):
        time.sleep(5)
        self.driver.quit()



if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(Bon_ration)
    unittest.TextTestRunner(verbosity=2).run(suite)
