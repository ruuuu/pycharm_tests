# -*- coding: utf-8 -*-

import os

import unittest
from appium import webdriver  #
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


class Bon_ration_authorazation(unittest.TestCase):

    def setUp(self):
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'
        desired_caps['app'] = '/Users/rufina/Desktop/ru.lifestyle.apk'  # обязательно путь к файлу приложения надо надо указывать, иначе убдет ошибку выдавать

        desired_caps['appPackage'] = 'ru.lifestyle'
        desired_caps['appActivity'] = 'ru.lifestyle.main.activity.MainActivity'

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)  # bybwbfkbpbhe.n lhfqdth


    def authorization(self):
        # burger:
        burger_button =  WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                             "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.Button[1]")))
        burger_button.click()

        voiti_button = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.widget.Button")))

        if voiti_button.is_enabled():
            voiti_button.click()
        else:
            print("voiti_button is not clikable")

        email_field = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.ID, "login-email-input")))

        if email_field.is_displayed():
            email_field.send_keys("rufinka_91@mail.ru")
        else:
            print("email_field is not visible")

        password_field = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.ID, "login-password-input")))

        if password_field.is_displayed():
            password_field.send_keys("7071991")
        else:
            print("password_field is not visible")

        authorazation_button = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[2]/android.widget.Button")))

        authorazation_button.click()
        time.sleep(2)

        self.driver.find_element_by_xpath(
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.Button[1]").click()


        time.sleep(1)
        # заходит в раздел заказы
        zakazy = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.view.View[2]/android.view.View[1]")))

        zakazy.click()




    def select_menu_items(self):


        item_my_feedback =   WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
             "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View/android.view.View[2]/android.view.View[2]")))
        item_my_feedback.click()

        # Наазад
        nazad_button = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH, "")))

        burger_button = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                                             "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.Button[1]")))

        time.sleep(1)
        burger_button.click()

        item_my_orders = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.view.View[2]/android.view.View[1]")))
        item_my_orders.click()

        time.sleep(1)
        nazad_button.click()

        elem = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[3]/android.widget.Button[2]")))

        elem.click()
        WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[2]/android.widget.Button"))).click()




    def test_authorization(self):  #


        # кнпока Пропустить
        propustu_button = self.driver.find_element_by_id("ru.lifestyle:id/skip")
        propustu_button.click()

        burger_button = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                                             "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.Button[1]")))
        burger_button.click()

        self.authorization()# вызываем автризацию

        time.sleep(2)

       # self.select_menu_items(burger_button) # вызываем метод меню





    def tearDown(self):
        time.sleep(5)
        self.driver.quit()





if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(Bon_ration_authorazation)
    unittest.TextTestRunner(verbosity=2).run(suite)
