# -*- coding: utf-8 -*-

import os

import unittest
from appium import webdriver  #
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from random import randint


class Bon_ration_calculator_and_pomosh(unittest.TestCase):

    def setUp(self):

        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'
        desired_caps['app'] = '/Users/rufina/Desktop/ru.lifestyle.apk'  # обязательно путь к файлу приложения надо надо указывать, иначе убдет ошибку выдавать

        desired_caps['appPackage'] = 'ru.lifestyle'
        desired_caps['appActivity'] = 'ru.lifestyle.main.activity.MainActivity'

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)  # bybwbfkbpbhe.n lhfqdth
        self.list_characters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
                                'R', 'S',
                                'T', 'U', 'W', 'X', 'Y', 'Z',
                                'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'k', 'm', 'n', 'o', 'p', 'q',
                                'r', 's',
                                't', 'u', 'w', 'x', 'y', 'z',
                                '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '&', '#', '*', '(', ')', '"', ',',
                                '/', ']',
                                '[', '}', '{', '"', '?', '!', '§', '±', '<', '№']  # поле


    def my_metho_randem_stroka(self, kolvo_bukv_v_slove, count_slov):

        list_slov = []
        # kolvo_bukv_v_slove = randint(3,5) # генерим ково букв в i-ом  слове

        for i in range(count_slov):  # цикл по колву слов, будет 5 слов  строке

            list_bukv = []
            for j in range(kolvo_bukv_v_slove):  # цикл по бкувам в i-ом слове

                list_bukv.append(' '.join([self.list_characters[randint(0, len(self.list_characters) - 1)]]))

            list_slov.append(''.join(list_bukv))

        return str(' '.join(list_slov))







    def authorization(self):
        # burger:
        burger_button =  WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                             "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.Button[1]")))
        burger_button.click()

        voiti_button = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.widget.Button")))

        if voiti_button.is_enabled():
            voiti_button.click()
        else:
            print("voiti_button is not clikable")

        el14 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button")))
        el14.click()

        el15 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.Button[1]")))
        el15.click()

        el166 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.widget.Button")))
        el166.click()

        email_field = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.ID, "login-email-input")))

        if email_field.is_displayed():
            email_field.send_keys("rufinka_91@mail.ru")
        else:
            print("email_field is not visible")

        password_field = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.ID, "login-password-input")))

        if password_field.is_displayed():
            password_field.send_keys("7071991")
        else:
            print("password_field is not visible")

        authorazation_button = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[2]/android.widget.Button")))

        authorazation_button.click()
        time.sleep(2)

        # кнопка бургера
        self.driver.find_element_by_xpath(
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.Button[1]").click()


        time.sleep(1)








    def test_calculatro(self):  #


        # кнпока Пропустить
        propustu_button = self.driver.find_element_by_id("ru.lifestyle:id/skip")
        propustu_button.click()

        burger_button = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                                             "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.Button[1]")))
        burger_button.click()

        self.authorization()# вызываем автризацию

        time.sleep(2)

        # бонусная программа:
        el1 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.view.View[4]")))
        el1.click()

        el2 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[2]/android.widget.Button")))
        el2.click()

        el3 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.Button[1]")))
        el3.click()

        el44 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.view.View[5]")))
        el44.click()

        el55 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[2]/android.widget.Button[2]")))
        el55.click()

        el6 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[4]/android.view.View/android.widget.Button")))
        el6.click()


        el7 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[4]/android.view.View[2]/android.view.View[3]")))
        el7.click()

        el8 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[6]/android.widget.Button")))
        el8.click()

        el9 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[6]/android.view.View/android.view.View[5]")))
        el9.click()

        el10 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[8]/android.widget.Button")))
        el10.click()

        el11 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[8]/android.view.View/android.view.View[5]")))
        el11.click()

        el12 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[10]/android.widget.Button")))
        el12.click()

        el13 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[10]/android.view.View/android.view.View[5]")))
        el13.click()

        el14 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[12]/android.view.View/android.widget.Button")))
        el14.click()

        el15 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[12]/android.view.View[2]/android.view.View[3]")))
        el15.click()

        el16 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[15]/android.widget.Button")))
        el16.click()

        el17 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[5]/android.view.View[15]/android.widget.Button")))
        el17.click()

        el18 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.Button")))
        el18.click()

        el19 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.Button")))
        el19.click()

        el20 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.view.View[7]")))
        el20.click()

        el21 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[2]/android.widget.Button")))
        el21.click()








    def tearDown(self):
        time.sleep(5)
        self.driver.quit()





if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(Bon_ration_calculator_and_pomosh)
    unittest.TextTestRunner(verbosity=2).run(suite)
