# -*- coding: utf-8 -*-

import os

import unittest
from appium import webdriver  #
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from random import randint

# можно выцарапывать элементы по его resouceId:
# self.driver.find_elements_by_android_uiautomator('new UiSelector().resourceId('')')

class Bon_ration_user_edit_order(unittest.TestCase):

    def setUp(self):

        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'
        desired_caps['app'] = '/Users/rufina/Desktop/ru.lifestyle.apk'  # обязательно путь к файлу приложения надо надо указывать, иначе убдет ошибку выдавать

        desired_caps['appPackage'] = 'ru.lifestyle'
        desired_caps['appActivity'] = 'ru.lifestyle.main.activity.MainActivity'

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)  # bybwbfkbpbhe.n lhfqdth
        self.list_characters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
                                'R', 'S',
                                'T', 'U', 'W', 'X', 'Y', 'Z',
                                'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'k', 'm', 'n', 'o', 'p', 'q',
                                'r', 's',
                                't', 'u', 'w', 'x', 'y', 'z',
                                '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '&', '#', '*', '(', ')', '"', ',',
                                '/', ']',
                                '[', '}', '{', '"', '?', '!', '§', '±', '<', '№']  # поле





    def authorization(self):
        time.sleep(4)

        el1 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[2]/android.widget.Button[1]")))
        el1.click()

        el2 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[1]/android.widget.Button")))
        el2.click()

        el3 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.ID,"login-email-input")))
        el3.send_keys("rufinka_91@mail.ru")

        el4 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.ID,"login-password-input")))
        el4.send_keys("7071991")

        el5 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[2]/android.widget.Button")))
        el5.click()

        time.sleep(5)
        # бургер
        el6 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[2]/android.widget.Button[1]")))
        el6.click()


    def test_edit_user_order(self):  ## надо чобы главный метод наичнался с  test!!!


        # кнпока Пропустить
        propustu_button = self.driver.find_element_by_id("ru.lifestyle:id/skip")
        propustu_button.click()

        time.sleep(10)

        self.authorization()# вызываем автризацию

        time.sleep(2)

        #раздел Заказы:

        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Заказы")').click()
        time.sleep(6)

        self.driver.find_elements_by_android_uiautomator('new UiSelector().text("ОТМЕНИТЬ")')[3].click() # instance=3

        #=self.driver.find_elements_by_class_name("")[] # 0=instance
        time.sleep(2)










    def tearDown(self):

        time.sleep(5)
        self.driver.quit()





if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(Bon_ration_user_edit_order)
    unittest.TextTestRunner(verbosity=2).run(suite)
