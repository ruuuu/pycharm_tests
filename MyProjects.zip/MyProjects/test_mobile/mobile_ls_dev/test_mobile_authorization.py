# -*- coding: utf-8 -*-

import os

import unittest
from appium import webdriver  #
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from random import randint


class Bon_ration_authorazation(unittest.TestCase):

    def setUp(self):
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'
        desired_caps['app'] = '/Users/rufina/Desktop/ru.lifestyle.apk'  # обязательно путь к файлу приложения надо надо указывать, иначе убдет ошибку выдавать

        desired_caps['appPackage'] = 'ru.lifestyle'
        desired_caps['appActivity'] = 'ru.lifestyle.main.activity.MainActivity'

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)  # bybwbfkbpbhe.n lhfqdth


    def authorization(self):

        time.sleep(6)
        #бургер
        el1 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[2]/android.widget.Button[1]")))
        el1.click()

        time.sleep(3)
        el2 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.view.View[2]")))
        el2.click()

        time.sleep(3)
        el3 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[6]/android.view.View/android.view.View")))
        el3.click()

        time.sleep(3)
        el4 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button")))
        el4.click()

        time.sleep(3)
        el5 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[2]/android.widget.Button[1]")))
        el5.click()

        time.sleep(3)
        el6 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[1]/android.widget.Button")))
        el6.click()

        time.sleep(3)
        el7 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.ID,"login-email-input")))
        el7.send_keys("rufinka_91@mail.ru")

        time.sleep(3)
        el8 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.ID, "login-password-input")))
        el8.send_keys("7071991")

        time.sleep(3)
        el9 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[2]/android.widget.Button")))
        el9.click()


    def method2(self):
        # жмем Бургер
        self.driver.find_elements_by_class_name("android.widget.Button")[1].click()  # 1=instance
        time.sleep(2)


        # путнкт выбор гоорда
        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Выбор города")').click()  #
        time.sleep(5)

        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Санкт-Петербург")').click()  #
        time.sleep(3)



        # жмем Крестик ввержху:
        self.driver.find_elements_by_class_name("android.widget.Button")[3].click()# 3=instance
        time.sleep(2)

        # жмем Бургер снова
        self.driver.find_elements_by_class_name("android.widget.Button")[1].click()  # 1=instance
        time.sleep(2)

        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Войти")').click() #  у атрибута text значенеи Войти
        time.sleep(2)

        #self.driver.find_elements_by_class_name("android.widget.EditText")[0].send_keys("rufinka_91@mail.ru")  # 0=instance
        self.driver.find_element_by_id("login-email-input").send_keys("rufinka_91@mail.ru")
        time.sleep(1)

        #self.driver.find_elements_by_class_name("android.widget.EditText")[1].send_keys("7071991")  # 1=instance
        self.driver.find_element_by_id("login-password-input").send_keys("7071991")
        time.sleep(1)

        # кнопка Войти
        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Войти")').click()
        time.sleep(3)

        # кнопка Поиск
        self.driver.find_elements_by_class_name("android.widget.Button")[1].click()  # 1=instance
        time.sleep(3)

        # вот здеаь останавливаетс:
        company = self.driver.find_element_by_class_name("android.widget.EditText").send_keys("городская компания")
        time.sleep(2)

        time.sleep(2)
        # стрелка Назад
        self.driver.find_elements_by_class_name("android.widget.Button")[2].click()  # 2=instance
        time.sleep(2)



        # жмем Бургер снова
        self.driver.find_elements_by_class_name("android.widget.Button")[0].click()  # 0=instance
        time.sleep(2)

        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Выйти")').click()  # у атрибута text значенеи Выйти






    def test_authorization(self):  ## надо чобы главный метод наичнался с  test!!!

        propustu_button = self.driver.find_element_by_id("ru.lifestyle:id/skip")
        propustu_button.click()
        time.sleep(15)
        #self.authorization()# вызываем автризацию
        self.method2()  # вызываем
        time.sleep(5)







    def tearDown(self):
        time.sleep(5)
        self.driver.quit()





if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(Bon_ration_authorazation)
    unittest.TextTestRunner(verbosity=2).run(suite)
