# -*- coding: utf-8 -*-

import os

import unittest
from appium import webdriver  #
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from random import randint
import string

class Bon_ration_registration(unittest.TestCase):

    def setUp(self):
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'
        desired_caps['app'] = '/Users/rufina/Desktop/ru.lifestyle.apk'  # обязательно путь к файлу приложения надо надо указывать, иначе убдет ошибку выдавать

        desired_caps['appPackage'] = 'ru.lifestyle'
        desired_caps['appActivity'] = 'ru.lifestyle.main.activity.MainActivity'

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)  # bybwbfkbpbhe.n lhfqdth

        self.list_characters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
                                'R', 'S',
                                'T', 'U', 'W', 'X', 'Y', 'Z',
                                'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'k', 'm', 'n', 'o', 'p', 'q',
                                'r', 's',
                                't', 'u', 'w', 'x', 'y', 'z']  # поле




    def my_metho_randem_stroka(self, kolvo_bukv_v_slove, count_slov):

        list_slov = []
        # kolvo_bukv_v_slove = randint(3,5) # генерим ково букв в i-ом  слове

        for i in range(count_slov):  # цикл по колву слов, будет 5 слов  строке

            list_bukv = []
            for j in range(kolvo_bukv_v_slove):  # цикл по бкувам в i-ом слове

                list_bukv.append(' '.join([self.list_characters[randint(0, len(self.list_characters) - 1)]]))

            list_slov.append(''.join(list_bukv))

        return str(' '.join(list_slov))


    def my_metho_randem_stroka_for_email(self, kolvo_bukv_v_slove, count_slov):

        list_characters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
                           'S', 'T', 'U', 'W', 'X', 'Y', 'Z',
                           'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'k', 'm', 'n', 'o', 'p', 'q', 'r',
                           's', 't', 'u', 'w', 'x', 'y', 'z',
                           '0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

        list_slov = []
        # kolvo_bukv_v_slove = randint(3,5) # генерим ково букв в i-ом  слове

        for i in range(count_slov):  # цикл по колву слов, будет 5 слов  строке

            list_slov = []
            # kolvo_bukv_v_slove = randint(3,5) # генерим ково букв в i-ом  слове

            for i in range(count_slov):  # цикл по колву слов, будет 5 слов  строке

                list_bukv = []
                for j in range(kolvo_bukv_v_slove):  # цикл по бкувам в i-ом слове

                    list_bukv.append(' '.join([list_characters[randint(0, len(list_characters) - 1)]]))

                list_slov.append(''.join(list_bukv))

        for_email = {0: "@yandex.ru", 1: "@mail.ru", 2: "@gmail.com"}
        return str(' '.join(list_slov)) + for_email[randint(0, 2)]




    def generation_tel_phone(self):  # генерит номер телфона

        list_digits = []
        for i in range(0, 10):

                # print(string.digits[randint(0,9)]) # 0123456789
                list_digits.append(string.digits[randint(1, 9)])

        #print("список цифр", list_digits)

        return str(' '.join(list_digits))


    def registration(self):

        time.sleep(6)
        #бургер
        burger = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[2]/android.widget.Button[1]")))

        burger.click()

        #self.driver.find_element_by_android_uiautomator('new UiSelector().text("")').click()

        time.sleep(1)

        # кнопка Войти
        voity = self.driver.find_element_by_android_uiautomator('new UiSelector().text("Войти")')
        voity.click()

        time.sleep(2)

        # в форме конпка Регитсрация
        register_button = self.driver.find_element_by_android_uiautomator('new UiSelector().text("Регистрация")')
        register_button.click()
        time.sleep(1)




        # кнопкка Крестик
        WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button"))).click()

        time.sleep(1)

        burger.click()
        time.sleep(1)
        voity.click()

        time.sleep(1)
        register_button.click()

        time.sleep(2)

        # поле Ваше имя, берет по resourceId
        field_name = self.driver.find_element_by_android_uiautomator('new UiSelector().resourceId("registration-name-input")')

        field_name.send_keys(self.my_metho_randem_stroka(randint(4,9), 1))
        time.sleep(1)

        # поле Email, берет по resourceId
        field_email = self.driver.find_element_by_android_uiautomator('new UiSelector().resourceId("registration-email-input")')
        field_email.send_keys(self.my_metho_randem_stroka_for_email(randint(4, 20), 1))
        time.sleep(1)



        phone_field = self.driver.find_element_by_android_uiautomator('new UiSelector().resourceId("registration-phone-input")')
        phone_field.send_keys(self.generation_tel_phone())
        # здесь пок ане хочет вбить, какие-то фиуры вбивает, какие-то нет




        time.sleep(1)


        field_password = self.driver.find_element_by_android_uiautomator('new UiSelector().resourceId("registration-password-input")')
        field_password.send_keys("password")

        time.sleep(1)

        # чекбокс:
        checkbox = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[6]")))
        checkbox.click()

        time.sleep(2)
        button_registartion = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.widget.Button[2]")))
        button_registartion.click()

        # нажимаем на Крестик в окнн подтверждения номера телефона
        WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button"))).click()

        # кнопка Пропустить в окне  Есть Промокод
        self.driver.find_element_by_android_uiautomator('new UiSelector().resourceId("ПРОПУСТИТЬ")').click()

        time.sleep(2)

        burger.click()





    def test_registration(self):  # # надо чобы главный метод наичнался с  test!!!

        propustu_button = self.driver.find_element_by_id("ru.lifestyle:id/skip")
        propustu_button.click()
        time.sleep(6)
        self.registration() # вызов метода

        time.sleep(5)







    def tearDown(self):
        time.sleep(5)
        self.driver.quit()





if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(Bon_ration_registration)
    unittest.TextTestRunner(verbosity=2).run(suite)
