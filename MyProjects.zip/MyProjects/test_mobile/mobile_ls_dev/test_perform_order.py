# -*- coding: utf-8 -*-

import os

import unittest
from appium import webdriver  #
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from random import randint

from appium.webdriver.common.touch_action import TouchAction # для скродда к элменту

class Bon_ration_perform_order(unittest.TestCase):

    def setUp(self):

        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'
        desired_caps['app'] = '/Users/rufina/Desktop/ru.lifestyle.apk'  # обязательно путь к файлу приложения надо надо указывать, иначе убдет ошибку выдавать

        desired_caps['appPackage'] = 'ru.lifestyle'
        desired_caps['appActivity'] = 'ru.lifestyle.main.activity.MainActivity'

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)  # bybwbfkbpbhe.n lhfqdth

        self.list_characters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
                                'R', 'S',
                                'T', 'U', 'W', 'X', 'Y', 'Z',
                                'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'k', 'm', 'n', 'o', 'p', 'q',
                                'r', 's',
                                't', 'u', 'w', 'x', 'y', 'z',
                                '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '&', '#', '*', '(', ')', '"', ',',
                                '/', ']',
                                '[', '}', '{', '"', '?', '!', '§', '±', '<', '№']  # поле


    def my_metho_randem_stroka(self, kolvo_bukv_v_slove, count_slov):

        list_slov = []
        # kolvo_bukv_v_slove = randint(3,5) # генерим ково букв в i-ом  слове

        for i in range(count_slov):  # цикл по колву слов, будет 5 слов  строке

            list_bukv = []
            for j in range(kolvo_bukv_v_slove):  # цикл по бкувам в i-ом слове

                list_bukv.append(' '.join([self.list_characters[randint(0, len(self.list_characters) - 1)]]))

            list_slov.append(''.join(list_bukv))

        return str(' '.join(list_slov))







    def authorization(self):
        time.sleep(6)
        # бургер
        el1 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                                   "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[2]/android.widget.Button[1]")))
        el1.click()
        time.sleep(3)
        #выбор городы
        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Выбор города")').click()

        time.sleep(2)
        # жмем казань
        WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[6]/android.view.View/android.view.View"))).click()

        time.sleep(5)

         # кнопка крестик
        WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button"))).click()

        time.sleep(3)

        # жмем бургер
        WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[2]/android.widget.Button[1]"))).click()
        time.sleep(2)

        #el2 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
        el2 = self.driver.find_element_by_android_uiautomator('new UiSelector().text("Войти")')                                                                         # "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.view.View[2]")))
        el2.click()

        time.sleep(3)



        email_filed = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[2]/android.widget.EditText[1]")))
        email_filed.send_keys("rufinka_91@mail.ru")
        time.sleep(3)

        password_filed = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[2]/android.widget.EditText[2]")))

        password_filed.send_keys("7071991")
        time.sleep(3)
        WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[2]/android.widget.Button"))).click()








    def test_perform_order(self):  ## надо чобы главный метод наичнался с  test!!!


        # кнпока Пропустить
        propustu_button = self.driver.find_element_by_id("ru.lifestyle:id/skip")
        propustu_button.click()

        time.sleep(10)

        self.authorization()

        # карточка комапнии
        el10 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[4]/android.view.View[2]")))
        el10.click()



        # карточка  рациона                                   не идет , так как  тут instance меняются
        #el13 = self.driver.find_elements_by_android_uiautomator('new UiSelector().text("ЗАКАЗАТЬ")')[68] # instace=68   у кнопки Заказать

        # карточка  рациона
        # говорит ошибка: Message: An element could not be located on the page using the given search parameters.
        #el13 = self.driver.find_element_by_xpath("//android.view.View[@text='ration']")

        # карточка  рациона
        # так не хочет
        #el13 = self.driver.find_elements_by_android_uiautomator('new UiSelector().text("ration jfgdjfgkd 100 ₽ / день 1245 ккал ЗАКАЗАТЬ")')

        # карточка  рациона
        el13 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[12]/android.view.View/android.view.View/android.view.View")))





        # вкладка Рационы
        #rations = self.driver.find_element_by_android_uiautomator('new UiSelector().text("Рационы")')

        label_nachisl =  self.driver.find_element_by_android_uiautomator('new UiSelector().text("Начисление баллов за заказ")')

        time.sleep(9)
        action = TouchAction(self.driver)
        for i in range(0, 9):
        #while el13.is_displayed() is False:  # пока элемент не виден скроллом, как только он станет видным, выход из цикла
            #print(el13.is_enabled() is False)
            action.press(el13).move_to(label_nachisl).release().perform()  # скролим от label_nachisl к el13
            time.sleep(3)


        el13.click()
        time.sleep(3)
        self.driver.find_element_by_android_uiautomator('new UiSelector().text("ЗАКАЗАТЬ")').click()
        time.sleep(3)

        duration = self.driver.find_element_by_android_uiautomator('new UiSelector().text("Длительность рациона")')
        duration.click()

        time.sleep(4)
        self.driver.find_element_by_android_uiautomator('new UiSelector().text("20 дней, 2 000 ₽")').click()

        #self.driver.find_elements_by_class_name("android.view.View")[randint(23, 28)].click()

        time.sleep(2)
        self.driver.find_elements_by_class_name("android.widget.EditText")[0].click()
        time.sleep(2)


        self.driver.find_elements_by_class_name("android.view.View")[51].click()
        time.sleep(2)











        #el14 = self.driver.find_element_by_android_uiautomator()"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[3]/android.view.View[5]/android.view.View[2]/android.view.View[2]/android.view.View[2]")))
        #el14.click()

        # el15 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.ID,"date-input-2")))
        # el15.click()
        #
        # el16 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
        #     "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[3]/android.view.View[6]/android.view.View[2]/android.view.View[1]/android.view.View[3]/android.view.View[2]/android.view.View[22]")))
        # el16.click()
        #
        # el17 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
        #     "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[3]/android.view.View[6]/android.view.View[2]/android.view.View[3]/android.widget.EditText")))
        # el17.click()
        #
        # el18 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
        #     "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[3]/android.view.View[6]/android.view.View[2]/android.view.View[3]/android.view.View[2]/android.view.View/android.view.View[2]/android.view.View[4]")))
        # el18.click()
        #
        # el19 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
        #     "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[3]/android.view.View[8]/android.widget.Button[2]")))
        # el19.click()
        #
        # el20 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
        #     "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[3]/android.view.View[12]/android.view.View/android.widget.Button")))
        # el20.click()
        #
        # el21 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
        #     "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[6]/android.widget.Button")))
        # el21.click()

    def tearDown(self):

        time.sleep(5)
        self.driver.quit()





if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(Bon_ration_perform_order)
    unittest.TextTestRunner(verbosity=2).run(suite)
