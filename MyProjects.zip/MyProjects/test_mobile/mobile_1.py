# -*- coding: utf-8 -*-



import os
import unittest
from appium import webdriver # все равно работает

from time import sleep


class ContactsAndroidTests(unittest.TestCase):

    def setUp(self):
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'
        desired_caps['app'] = '/Users/rufina/Desktop/ContactManager.apk' # обязательно путь к файлу приложения надо надо указывать, иначе убдет ошибку выдавать


        desired_caps['appPackage'] = 'com.example.android.contactmanager'
        desired_caps['appActivity'] = '.ContactManager'

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)


    def tearDown(self):
        self.driver.quit()


    def test_add_contacts(self):

        el = self.driver.find_element_by_accessibility_id("Add Contact")
        el.click()

        textfields = self.driver.find_elements_by_class_name("android.widget.EditText")
        textfields[0].send_keys("Appium User")
        textfields[2].send_keys("someone@appium.io")


        self.driver.find_element_by_accessibility_id("Save").click()






if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(ContactsAndroidTests) # в с кобках укаазываем название  этого класса
    unittest.TextTestRunner(verbosity=2).run(suite)