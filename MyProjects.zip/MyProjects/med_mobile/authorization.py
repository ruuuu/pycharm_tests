# -*- coding: utf-8 -*-

import os

import unittest
from appium import webdriver  #
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from random import randint


class med_authorization(unittest.TestCase):

    def setUp(self):
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'
        desired_caps['app'] = '/Users/rufina/Desktop/ru.akbarsmed.apk'  # обязательно путь к файлу приложения надо надо указывать, иначе убдет ошибку выдавать

        desired_caps['appPackage'] = 'ru.akbarsmed'
        desired_caps['appActivity'] = 'host.exp.exponent.MainActivity'

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)  # bybwbfkbpbhe.n lhfqdth


    def test_authorization(self): #  начдо чтобы гдавный метод начинался с test

        time.sleep(4)

        for i in range(0, 3):
            self.driver.find_element_by_android_uiautomator('new UiSelector().text("Далее")').click() # кнопка Далее
            time.sleep(2)

        # номер телеофна
        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Номер телефона")').send_keys("89274435637")
        time.sleep(3)
        # Пароль
        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Пароль")').send_keys("567890")
        time.sleep(3)

        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Войти")').click() # кнопка Войти
        time.sleep(6)

        # экран профиля
        # жмем Личные данные
        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Личные данные")').click()  #
        time.sleep(6)


        # #  жмем поле ФИО
        # self.driver.find_element_by_android_uiautomator('new UiSelector().text("testone testfree testtwo ")').click() # придется потсоянном енять, по=другому никак
        # time.sleep(2)

        # страница изменения ФИО:
        # поле Фамилия


        # fio = self.driver.find_element_by_android_uiautomator('new UiSelector().text("testone")')
        # fio.clear()
        # time.sleep(1)
        # fio1 = self.driver.find_element_by_android_uiautomator('new UiSelector().text("Фамилия")')
        # fio1.send_keys("Pavlova")
        # time.sleep(1)
        #
        # # поле Имя
        #
        # name = self.driver.find_element_by_android_uiautomator('new UiSelector().text("testtwo")')
        # name.clear()
        # time.sleep(1)
        # name1 =  self.driver.find_element_by_android_uiautomator('new UiSelector().text("Имя")')
        # name1.send_keys("MArina")
        # time.sleep(1)
        #
        # # поле Отчество
        #
        # otchestvo = self.driver.find_element_by_android_uiautomator('new UiSelector().text("testfree")')
        # otchestvo.clear()
        # time.sleep(1)
        # otchestvo1 = self.driver.find_element_by_android_uiautomator('new UiSelector().text("Отчество")')
        #
        # otchestvo1.send_keys("ghgjh")
        # time.sleep(2)

        #Кнопка Сохранить
        # self.driver.find_element_by_android_uiautomator('new UiSelector().text("Сохранить")').click()
        # time.sleep(2)

        #-------------------------
        # меняем Пол:
        # time.sleep(3)
        # self.driver.find_element_by_android_uiautomator('new UiSelector().text("Женский")').click() #
        # time.sleep(2)
        #
        # pol = {0: 'Мужской', 1: 'Женский'}
        # self.driver.find_element_by_android_uiautomator('new UiSelector().text(pol[randint(0, 1)])').click()
        # time.sleep(2)

        #-----------------------------
        #меняем рост
        self.driver.find_element_by_android_uiautomator('new UiSelector().text("46 м")').click()

        time.sleep(2)


        #менеям возраст
        # берем по resourseId (нижняя стрелочка)
        self.driver.find_element_by_android_uiautomator('new UiSelector().resourceId("android:id/text1")').click()
        time.sleep(2)

        # список возрастов
        list_ages = WebDriverWait(self.driver, 10).until(ec.presence_of_all_elements_located((By.CLASS_NAME, "android.widget.CheckedTextView")))

        rand_age_index = randint(0, len(list_ages)-1) # берет раномнй возраст

        list_ages[rand_age_index].click()
        time.sleep(2)

        # кнопка Ок
        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Ок")').click()

        # #менеям Вес
        self.driver.find_element_by_android_uiautomator('new UiSelector().text("45 кг")').click()
        time.sleep(2)

        WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.CLASS_NAME, "android.widget.Spinner"))).click()
        time.sleep(2)

        # список масс
        list_weights = WebDriverWait(self.driver, 10).until(ec.presence_of_all_elements_located((By.CLASS_NAME, "android.widget.CheckedTextView")))
        rand_weight_index = randint(0, len(list_weights) - 1)  # берет раномнй вес
        list_weights[rand_weight_index].click()
        time.sleep(2)

        # кнопка Ок
        self.driver.find_element_by_android_uiautomator('new UiSelector().text("Ок")').click()
        time.sleep(2)


        # меняем Адрес

        # time.sleep(2)

        # el7 = WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.ID,"login-email-input")))













    def tearDown(self):
        time.sleep(5)
        self.driver.quit()





if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(med_authorization) #  в скобках указывается название класса
    unittest.TextTestRunner(verbosity=2).run(suite)
