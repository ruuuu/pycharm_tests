import time
import unittest
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains # lля сколддинга к нужному элементу импортируем класс ActionChains

import pytest
 # здесь  филрация промокодов и поиск

class filtres_and_search_promocodes(unittest.TestCase):


    def authorization(self, driver): # авторизация

        driver.get("https://devadmin.bonration.ru/external/login")


        try:
            email_field = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//*[@id='mat-input-0']" )))#
            email_field.send_keys("b10ocgshrnwu@mail.ru")
        except :
            time.sleep(5)
            email_field.send_keys("b10ocgshrnwu@mail.ru")

        try:
            password_field = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//*[@id='mat-input-1']" )))
            password_field.send_keys("password")
        except:
            time.sleep(5)
            password_field.send_keys("password")

        button_voity = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                                       "/html/body/app-root/portal-login/div/mat-card/mat-card-content[2]/div/div/div/app-spinner-button/button")))
        if button_voity.is_displayed():  # если кнпока видна , то
            button_voity.click()
            print("button is visible")


    def setUp(self):
        self.driver = webdriver.Chrome()

        #self.driver.set_window_position(0, 0)  # устанавливает позицию левого вурзнего угла окна браузера
        self.driver.set_window_size(1440, 900)  # устанавливае мразмеры окна


        #self.driver.maximize_window()
        # self.driver.implicitly_wait(10) # для  явных ожиданий, будет вызываться перед каждвм методом find_element()


    def test_filtres_and_search_promocodes(self):  # главный метод, надо чтобы он начинался  с test_

        driver = self.driver
        self.authorization(driver)  # вызов метода,котрый выше
        time.sleep(4)  # чтобы сразу окно не закрывалось

        # жмем на рfздел Gромокоды
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH, "//a[@href='/superadmin/promocodes']"))).click()

        time.sleep(2)

        # сортируем по ID
        for i in range(0, 3):
            WebDriverWait(driver, 10).until(
                ec.element_to_be_clickable((By.XPATH, "//button[@aria-label='Change sorting for id']"))).click()
            time.sleep(2)

        # сортируем по Название
        for i in range(0, 3):
            WebDriverWait(driver, 10).until(
                    ec.element_to_be_clickable((By.XPATH, "//button[@aria-label='Change sorting for name']"))).click()
            time.sleep(2)

        # сортируем по Срок
        for i in range(0, 3):
            WebDriverWait(driver, 10).until(
                    ec.element_to_be_clickable((By.XPATH, "//button[@aria-label='Change sorting for start_date_ms']"))).click()
            time.sleep(2)

        time.sleep(2)





    def tear_down(self):
        self.driver.quit()
        # pass


if __name__ == "__main__":
    unittest.main()



