# -*- coding: utf-8 -*-
import time
import unittest
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains # lля сколддинга к нужному элементу импортируем класс ActionChains




from random import randint
import string

import pytest

 # здесь  авторизация админа(компаний)

class Test_our(unittest.TestCase):



    def setUp(self):


        self.browser = webdriver.Chrome()


    def test_test1(self):  # главный метод, надо чтобы он начинался  с test_

        self.browser.get("http://suninjuly.github.io/registration1.html")

        input1 = self.browser.find_element_by_xpath("//input[@placeholder='Input your first name']")
        input1.send_keys("Ivan")

        input2 = self.browser.find_element_by_xpath("//input[@placeholder='Input your last name']")
        input2.send_keys("Petrov")

        input3 = self.browser.find_element_by_xpath("//input[@placeholder='Input your email']")
        input3.send_keys("nsk989@df.uiy")

        input4 = self.browser.find_element_by_xpath("//input[@placeholder='Input your phone:']")
        input4.send_keys("8909098765")

        input5 = self.browser.find_element_by_xpath("//input[@placeholder='Input your address:']")
        input5.send_keys("Первомайская")

        button = self.browser.find_element_by_xpath("//button[text()='Submit']")
        button.click()


    def test_test2(self):

        self.browser.get("http://suninjuly.github.io/registration2.html")

        input11 = self.browser.find_element_by_tag_name("input")
        input11.send_keys("Ivan")

        input21 = self.browser.find_element_by_xpath("//input[@placeholder='Input your email']")
        input21.send_keys("Ivan@mmt.rt")

        input31 = self.browser.find_element_by_xpath("//input[@placeholder='Input your phone']")
        input31.send_keys("8909876545")

        input41 = self.browser.find_element_by_xpath("//input[@placeholder='Input your address']")
        input41.send_keys("Первоайская")

        button = self.browser.find_element_by_xpath("//button[text()='Submit']")
        button.click()

        #self.assertEqual(sum([1, 2, 3]), 6, "Should be 6")



    def tear_down(self):

        self.browser.quit()
        # pass


if __name__ == "__main__":
    unittest.main()



