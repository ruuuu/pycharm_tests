import time
import unittest
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains # lля сколддинга к нужному элементу импортируем класс ActionChains

import pytest
from  random import randint
import string

class Client_sent_zayavka(unittest.TestCase):


    def authorization(self, driver): # авторизация

        driver.get("https://ertc-dev.technaxis.com/auth/login")


        try:
            email_field = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='email']" )))#
            email_field.send_keys("dfsdh@mail.ru")
        except :
            time.sleep(5)
            email_field.send_keys("dfsdh@mail.ru")

        try:
            password_field = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='password']" )))
            password_field.send_keys("striNg3")
        except:
            time.sleep(5)
            password_field.send_keys("striNg3")

        button_voity = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                                       "//button[@class='mat-raised-button']")))
        if button_voity.is_displayed():  # если кнпока видна , то
            button_voity.click()
            print("button is visible")


    def my_metho_randem_stroka(self, kolvo_bukv_v_slove, count_slov):  # генерит предложение

        list_slov = []
        # kolvo_bukv_v_slove = randint(3,5) # генерим ково букв в i-ом  слове

        for i in range(count_slov):  # цикл по колву слов, будет 5 слов  строке

            list_bukv = []
            for j in range(kolvo_bukv_v_slove):  # цикл по бкувам в i-ом слове

                list_bukv.append(' '.join([self.list_characters[randint(0, len(self.list_characters) - 1)]]))

            list_slov.append(''.join(list_bukv))

        return str(' '.join(list_slov))

    def my_metho_randem_stroka_with_digit(self, kolvo_bukv_v_slove, count_slov):

        list_slov = []
        # kolvo_bukv_v_slove = randint(3,5) # генерим ково букв в i-ом  слове

        for i in range(count_slov):  # цикл по колву слов, будет 5 слов  строке

            list_bukv = []
            for j in range(kolvo_bukv_v_slove):  # цикл по бкувам в i-ом слове

                list_bukv.append(' '.join([self.list_characters_digit[randint(0, len(self.list_characters_digit) - 1)]]))

            list_slov.append(''.join(list_bukv))

        return str(' '.join(list_slov))



    def setUp(self):
        self.driver = webdriver.Chrome()

        self.driver.set_window_position(0, 0)  # устанавливает позицию левого вурзнего угла окна браузера
        self.driver.set_window_size(1440, 900)  # устанавливае мразмеры окна


        #self.driver.maximize_window()
        # self.driver.implicitly_wait(10) # для  явных ожиданий, будет вызываться перед каждвм методом find_element()
        self.list_characters_digit = [ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' ]
        self.list_characters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
                           'S', 'T', 'U', 'W', 'X', 'Y', 'Z',
                           'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'k', 'm', 'n', 'o', 'p', 'q', 'r',
                           's', 't', 'u', 'w', 'x', 'y', 'z']

    def test_method_client_authorization(self):  # главный метод, надо чтобы он начинался  с test_

        driver = self.driver
        self.authorization(driver)  # вызов метода,котрый выше
        time.sleep(4)  # чтобы сразу окно не закрывалось

        #нажимаем на маленьки трегуольник для выбора страны
        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//div[@class='mat-form-field-infix']"))).click()
        time.sleep(2)

        list_countries = WebDriverWait(driver, 10).until(ec.visibility_of_all_elements_located((By.XPATH,"//mat-option[@class='mat-option ng-star-inserted']")))

        random_index_of_country = randint(0, len(list_countries)-1) # выбраем рандомную страну
        print("random_index_of_country equal", random_index_of_country )
        list_countries[random_index_of_country].click()

        time.sleep(2)

        # кнопка Далее
        WebDriverWait(driver, 10).until(ec.element_to_be_clickable((By.XPATH, "//button[@class='fluid mat-raised-button']"))).click()
        time.sleep(2)

        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH,"//input[@formcontrolname='fullName']"))).send_keys(self.my_metho_randem_stroka(randint(4, 10), randint(1, 3)))
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='cadastralNumber']"))).send_keys(self.my_metho_randem_stroka_with_digit(randint(5,10),1))
        time.sleep(2)

        # загрукза файлов:
        file_dicitionary = {0: "/Users/rufina/Desktop/bunkets/2d1febbc8a2d4538dafb620c293749d2.jpg",
                            1: "/Users/rufina/Desktop/bunkets/08_big.jpg", 2: "/Users/rufina/Desktop/bunkets/9.jpg",
                            3: "/Users/rufina/Desktop/bunkets/96bfd35718e29bbd8f50e8fb2e1ee004.jpg",
                            4: "/Users/rufina/Desktop/bunkets/260_image_775x470_Energiya vkusa banketnyy zal 6.jpg",
                            5: "/Users/rufina/Desktop/bunkets/260_image_775x470_Energiya vkusa banketnyy zal 6.jpg",
                            6: "/Users/rufina/Desktop/bunkets/36866_1143.jpg",
                            7: "/Users/rufina/Desktop/bunkets/2875451.jpg", 8: "/Users/rufina/Desktop/bunkets/",
                            9: "/Users/rufina/Desktop/bunkets/23292.jpg",
                            10: "/Users/rufina/Desktop/bunkets/6599_ho_00_p_2048x1536.jpg",
                            11: "/Users/rufina/Desktop/bunkets/572a8b9f2385ae96e327146cb884118d.JPG",
                            12: "/Users/rufina/Desktop/bunkets/2875451.jpg",
                            13: "/Users/rufina/Desktop/bunkets/36866_1143.jpg",
                            14: "/Users/rufina/Desktop/bunkets/2875451.jpg",
                            15: "/Users/rufina/Desktop/bunkets/7081014_YRGu-QpsDK1Oi6yBuXp6j28YLCR210WS8tzyXjM_X9c.jpg",
                            16: "/Users/rufina/Desktop/bunkets/19693651325639393cb80ee.jpg",
                            17: "/Users/rufina/Desktop/bunkets/султанат2.jpg",
                            18: "/Users/rufina/Desktop/bunkets/султанат2.jpg",
                            19: "/Users/rufina/Desktop/bunkets/a3b1.jpg", 20: "/Users/rufina/Desktop/bunkets/big_1.jpg",
                            21: "/Users/rufina/Desktop/bunkets/caption.jpg",
                            22: "/Users/rufina/Desktop/bunkets/Customized-Design-Printed-Carpet-for-Banquet-Hall-Hotel-Room.jpg",
                            23: "/Users/rufina/Desktop/bunkets/filef46175f6d7587cddba037b3fa3d90cd8.jpg",
                            24: "/Users/rufina/Desktop/bunkets/kriviera_16.jpg",
                            25: "/Users/rufina/Desktop/bunkets/maxresdefault (1).jpg"}

        files = WebDriverWait(driver, 10).until(
            ec.presence_of_all_elements_located((By.XPATH, "//input[@type='file']")))

        for i in range(0, 3):
            files[i].send_keys(file_dicitionary[randint(0, len(file_dicitionary) - 1)])
            time.sleep(2)


        # жмем Далее
        WebDriverWait(driver, 10).until(ec.element_to_be_clickable((By.XPATH,"//button[@class='submit mat-raised-button']"))).click()
        time.sleep(3)

        # кнопка Подтвердить
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH, "//button[@class='mat-raised-button']"))).click()
        time.sleep(5)



    def tear_down(self):
        #self.driver.quit()
         self.driver.close() # закрывает окно браузера
        # pass


if __name__ == "__main__":
    unittest.main()



