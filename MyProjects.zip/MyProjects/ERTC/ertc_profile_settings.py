import time
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.by import By
from random import randint



driver = webdriver.Chrome()

driver.get("https://ertc-dev.technaxis.com/console/settings/notifications")

try:
    email_field = WebDriverWait(driver, 10).until(
        ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='email']")))  #
    email_field.send_keys("dfsdh@mail.ru")
except:
    time.sleep(5)
    email_field.send_keys("dfsdh@mail.ru")

try:
    password_field = WebDriverWait(driver, 10).until(
        ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='password']")))
    password_field.send_keys("striNg3")
except:
    time.sleep(5)
    password_field.send_keys("striNg3")


button_voity = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                               "//button[@class='mat-raised-button']")))
if button_voity.is_displayed():  # если кнпока видна , то
    button_voity.click()
    print("button is visible")

time.sleep(2)

#  кнопкпка Настройка профиля
WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//a[@href='/console/settings/account']"))).click()

time.sleep(2)

WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//a[@href='/console/settings/notifications']"))).click()
time.sleep(2)

for i in range(0, 4):

    WebDriverWait(driver, 10).until(ec.presence_of_all_elements_located((By.XPATH, "//div[@class='mat-checkbox-inner-container']")))[i].click()
    time.sleep(1)


time.sleep(3)




driver.close() # браузерное окно закрывается

# file_dictionary = {0: "/Users/rufina/Desktop/dishs/BjJ6inaYiWam0GGViLFHLQ-double.jpg",
#                             1: "/Users/rufina/Desktop/dishs/4Rve51WmWfk.jpg", 2: "/Users/rufina/Desktop/dishs/2531.jpg",
#                             3: "/Users/rufina/Desktop/dishs/salat_kinoa.jpg__1499258543__50030.jpg",
#                             4: "/Users/rufina/Desktop/dishs/4703.jpg", 5: "/Users/rufina/Desktop/dishs/caption (1).jpg"}
#
# WebDriverWait(driver, 10)\
#     .until(ec.presence_of_element_located((By.XPATH, "//button[@class='mat-stroked-button']"))).click()# press
#
# time.sleep(2)
#
# WebDriverWait(driver, 10).until(ec.presence_of_element_located(By.XPATH, "//input[@type='file']")).send_keys("/Users/rufina/Desktop/dishs/4703.jpg")
# time.sleep(2)
#
# WebDriverWait(driver, 10)\
#     .until(ec.presence_of_element_located((By.XPATH, "//button[@type='submit']")))\
#     .click()