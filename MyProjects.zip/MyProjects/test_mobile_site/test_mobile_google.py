# -*- coding: utf-8 -*-


import sys
import time
import unittest
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec



# темстирование google в  мобильном браузере chrome
class google_mobile(unittest.TestCase):

    def setUp(self):

        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'

        desired_caps['appPackage'] = 'com.android.vending' #для приложения
        desired_caps['appActivity'] = 'com.android.vending.AssetBrowserActivity' # для приложения

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)  # bybwbfkbpbhe.n lhfqdth





    def test_google(self):

        driver = self.driver
        #driver.find_element_by_id("com.android.vending:id/search_box_idle_text").send_keys("фильмы") # нашли элемент по его id
        #time.sleep(2)
        # или можно так:
        driver.find_element_by_xpath("//android.widget.ImageView[@content-desc='Поиск.']").send_keys("фильмы") # нашли элемент по xpath

        # или вот атк:
        #driver.find_element_by_xpath("//*[@text='']")


        menu_items = driver.find_elements_by_xpath("//android.widget.TextView")
        # for item in menu_items:
        #
        #     if item.get_attribute("text") == 'ГЛАВНАЯ':
        #         item.click()
        #         time.sleep(2)


        # time.sleep(2)
        # driver.find_element_by_xpath("//android.widget.TextView[@text='ИГРЫ']").click()
        # time.sleep(2)
        # driver.find_element_by_xpath("//android.widget.TextView[@text='ФИЛЬМЫ']").click()
        #
        # driver.find_element_by_id("com.android.vending:id/search_box_idle_text").send_keys("флиьм") # по id взяли

        #driver.find_elements_by_class_name("android.view.View")[50].click() # события

        # elem = driver.find_element(By.XPATH, "//android.widget.Button[@text = '17']") # не хочет
        # if elem.is_displayed(): # если звонок видимы то кликнет
        #     elem.click()


        #driver.implicitly_wait(5)










    def tearDown(self):

        time.sleep(5)
        self.driver.quit()
        #self.driver.close()







if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(google_mobile)
    unittest.TextTestRunner(verbosity=2).run(suite)

