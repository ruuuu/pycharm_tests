# -*- coding: utf-8 -*-


import sys
import time
import unittest
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec



# темстирование леруа в  мобильном браузере chrome
class lerua_mobile(unittest.TestCase):

    def setUp(self):

        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'
        desired_caps['browserName'] = 'chrome' #  'chrome' указываем браузер в котром будем тестить

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)  # bybwbfkbpbhe.n lhfqdth


    def authorization(self, driver):  # авторизация

        driver.get('https://admin:LY1R1VMXJ1@dev.leroyfactory.ru')  # чтобы обойти базовую аунтентификацию
        # driver.get("https://dev.leroyfactory.ru/main")

        #кнопка Войти:
        driver.find_element_by_xpath(".//*[text()='Войти']/..").click()

        time.sleep(2)
        # атворизуемся
        login = driver.find_element_by_xpath("//input[@formcontrolname='login']")
        login.send_keys("admin@mail.ru")

        time.sleep(2)
        password_d = driver.find_element_by_xpath("//input[@formcontrolname='password']")
        password_d.send_keys("password")

        time.sleep(2)
        but_send = driver.find_element_by_xpath("//button[@class ='btn-green btn signin-submit-button']")  # отправть
        but_send.click()


    def test_lerua(self):

        driver = self.driver
        driver.get('https://admin:LY1R1VMXJ1@dev.leroyfactory.ru')  # чтобы обойти базовую аунтентификацию
        self.authorization(driver)  # вызов метода  авторизации,котрый выше

        time.sleep(10)

        #driver.find_element_by_class_name("android.widget.Button").click()  #ГЛАВНАЯ не хочет
        #driver.find_element_by_xpath("//*[@text = 'Главная']").click() # не хочет
        #driver.find_element_by_xpath(".//*[text()='Главная']/..").click() # не хочет

        #driver.find_element_by_xpath("//android.widget.Button[@name='Главная']").click() #  не хочетберем элемен по text


        #driver.find_element_by_name("Главная").click() # не хочет

        # попробоват по link

        driver.find_element_by_xpath("//a[@class='logo']").click()


        driver.execute_script("window.scrollBy(326, 915);")
        time.sleep(2)
        #driver.find_element_by_xpath("//a[@href='/idei']").click()
        driver.find_elements_by_xpath("//div[@class='idea-info']")[0].click()
        time.sleep(3)

        # здесь выдает шибку
        WebDriverWait(driver, 15).until(ec.presence_of_element_located(
            (By.XPATH, "//button[@class='btn sprite-btn likes-btn likes-btn-no-shadow sprite-btn-no-shadow']"))).click() # нажимаем на лайк


        time.sleep(2)

        abonement = WebDriverWait(driver, 15).until(ec.presence_of_element_located(
            (By.XPATH,
             "//button[@class='btn btn-green buy-subscription-btn']")))# кнопка заказать аонемент



        driver.execute_script("arguments[0].scrollIntoView(true);", abonement)
        time.sleep(2)
        abonement.click()






        #driver.find_element_by_xpath("//android.widget.Button[@text = '17']").click() # не хочет
        #time.sleep(3)
        #driver.find_elements_by_class_name("android.view.View")[50].click() # события

        # elem = driver.find_element(By.XPATH, "//android.widget.Button[@text = '17']") # не хочет
        # if elem.is_displayed(): # если звонок видимы то кликнет
        #     elem.click()

        # elements = driver.find_elements_by_xpath("//android.widget.Button") # в цикле будем перебирать все элементы у котрых есть класс  android.widget.Button
        #
        # for i in elements:
        #
        #     if i.get_attribute("text") == 'Главная':# если еткст на элементе равен "Главная"
        #         time.sleep(2)
        #         i.click()
        #
        #         break

        # driver.find_element_by_xpath("//android.widget.Button[@name='Главная']").click()  # берем элемен по text
        #
        # time.sleep(5)
        # # из меню выбираем пунтк:
        # elements_menu = driver.find_elements_by_xpath("//android.view.View")
        # time.sleep(2)
        #
        # for m in elements_menu:
        #
        #     if m.get_attribute("text") == 'Идеи': #если еткст на элементе равен "Идеи"
        #         time.sleep(2)
        #         m.click()
        #         break
        #
        #
        # time.sleep(1)
        # ideas = driver.find_elements_by_xpath("//android.view.View")
        #
        # for idea in ideas:
        #
        #     if idea.get_attribute("name") == 'В раздел "Идеи" ->':
        #         idea.click()
        #         break

        #driver.find_element_by_xpath('//android.view.View[@name="В раздел "Идеи" ->"]').click()

        # buttons = driver.find_elements_by_xpath("//android.view.View")
        # time.sleep(2)
        # for b in buttons:
        #     if b.get_attribute("text") == 'Подробнее':  # если еткст на элементе равен "Главная"
        #         time.sleep(2)
        #         b.click()
        #         break

        time.sleep(5)

        #driver.implicitly_wait(5)


        time.sleep(5)






    def tearDown(self):

        time.sleep(5)
        self.driver.quit()
        #self.driver.close() # закрываем браузер







if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(lerua_mobile)
    unittest.TextTestRunner(verbosity=2).run(suite)

