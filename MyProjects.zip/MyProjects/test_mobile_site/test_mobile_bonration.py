# -*- coding: utf-8 -*-


import sys
import time
import unittest
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec



# темстирование рационов в  мобильном браузере chrome
class bonration_mobile(unittest.TestCase):

    def setUp(self):

        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '5.0.2'
        desired_caps['deviceName'] = '0123456789ABCDEF'
        desired_caps['browserName'] = 'chrome' #  'chrome' указываем браузер в котром будем тестить

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)  # bybwbfkbpbhe.n lhfqdth


    def authorization(self, driver):  # авторизация


        driver.get("https://devclient.bonration.ru")

        #кнопка Войти:
        driver.find_element_by_xpath(".//*[text()='Войти']/..").click()

        time.sleep(2)
        # атворизуемся
        login = driver.find_element_by_xpath("//input[@formcontrolname='login']")
        login.send_keys("admin@mail.ru")

        time.sleep(2)
        password_d = driver.find_element_by_xpath("//input[@formcontrolname='password']")
        password_d.send_keys("password")

        time.sleep(2)
        but_send = driver.find_element_by_xpath("//button[@class ='btn-green btn signin-submit-button']")  # отправть
        but_send.click()


    def test_bonration(self):

        driver = self.driver
        driver.get("https://devclient.bonration.ru")

        #self.authorization(driver)  # вызов метода  авторизации,котрый выше


        time.sleep(5)
        driver.find_element_by_xpath(".//*[text()='Найти рацион']/..").click() #Нажимает на калькулятор калорий

        time.sleep(2)
        #driver.find_element_by_xpath("//android.widget.Button[@name='Мужской']").click()# не хочет

        buttons = driver.find_elements_by_xpath("//android.widget.Button")
        time.sleep(2)
        for b in buttons:
            if b.get_attribute("text") == 'Мужской':  # если еткст на элементе равен "Мужской"
                time.sleep(2)
                b.click()
                break

        driver.find_element_by_xpath(".//*[text()='Выбрать цель']/..").click()
        time.sleep(2)

        driver.find_element_by_xpath(".//*[text()='Набор массы']/..").click()
        time.sleep(2)
        #driver.find_elements_by_class_name("android.widget.EditText").send_keys("142") # рост

        driver.find_element_by_xpath(".//*[class()='android.widget.EditText']/..").send_keys("142")




        time.sleep(2)
        # driver.find_elements_by_class_name("android.widget.EditText")[1].send_keys("21") # возраст
        # time.sleep(2)
        # driver.find_elements_by_class_name("android.widget.EditText")[2].send_keys("44") # вес






        #driver.find_element_by_class_name("android.widget.Button").click()  #ГЛАВНАЯ не хочет
        #driver.find_element_by_xpath("//*[@text = 'Главная']").click() # не хочет
        #driver.find_element_by_xpath(".//*[text()='Главная']/..").click() # не хочет

        #driver.find_element_by_xpath("//android.widget.Button[@name='Главная']").click() #  не хочетберем элемен по text


        #driver.find_element_by_name("Главная").click() # не хочет

        # попробоват по link



        #driver.execute_script("window.scrollBy(326, 915);")
        time.sleep(2)




        #driver.find_element_by_xpath("//android.widget.Button[@text = '17']").click() # не хочет
        #time.sleep(3)
        #driver.find_elements_by_class_name("android.view.View")[50].click() # события

        # elem = driver.find_element(By.XPATH, "//android.widget.Button[@text = '17']") # не хочет
        # if elem.is_displayed(): # если звонок видимы то кликнет
        #     elem.click()

        # elements = driver.find_elements_by_xpath("//android.widget.Button") # в цикле будем перебирать все элементы у котрых есть класс  android.widget.Button
        #
        # for i in elements:
        #
        #     if i.get_attribute("text") == 'Главная':# если еткст на элементе равен "Главная"
        #         time.sleep(2)
        #         i.click()
        #
        #         break

        # driver.find_element_by_xpath("//android.widget.Button[@name='Главная']").click()  # берем элемен по text
        #
        # time.sleep(5)
        # # из меню выбираем пунтк:
        # elements_menu = driver.find_elements_by_xpath("//android.view.View")
        # time.sleep(2)
        #
        # for m in elements_menu:
        #
        #     if m.get_attribute("text") == 'Идеи': #если еткст на элементе равен "Идеи"
        #         time.sleep(2)
        #         m.click()
        #         break
        #
        #
        # time.sleep(1)






    def tearDown(self):

        time.sleep(5)
        self.driver.quit()
        #self.driver.close() # закрываем браузер







if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(bonration_mobile) # указываем название класса
    unittest.TextTestRunner(verbosity=2).run(suite)

