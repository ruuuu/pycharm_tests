import time
import unittest
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains # lля сколддинга к нужному элементу импортируем класс ActionChains
from random import randint
import string


import pytest
 # здесь  О промоутере редактируем информацию

class about_promouter(unittest.TestCase):


    def authorization(self, driver): # авторизация

        driver.get("https://devadmin.bonration.ru/external/login")


        try:
            email_field = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//*[@id='mat-input-0']" )))#
            email_field.send_keys("b10ocgshrnwu@mail.ru")
        except :
            time.sleep(5)
            email_field.send_keys("b10ocgshrnwu@mail.ru")

        try:
            password_field = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//*[@id='mat-input-1']" )))
            password_field.send_keys("password")
        except:
            time.sleep(5)
            password_field.send_keys("password")

        button_voity = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                                       "/html/body/app-root/portal-login/div/mat-card/mat-card-content[2]/div/div/div/app-spinner-button/button")))
        if button_voity.is_displayed():  # если кнпока видна , то
            button_voity.click()
            print("button is visible")



    def my_metho_randem_stroka(self, kolvo_bukv_v_slove, count_slov): # генерит предложение

        list_slov = []
        # kolvo_bukv_v_slove = randint(3,5) # генерим ково букв в i-ом  слове

        for i in range(count_slov):  # цикл по колву слов, будет 5 слов  строке

            list_bukv = []
            for j in range(kolvo_bukv_v_slove):  # цикл по бкувам в i-ом слове

                list_bukv.append(' '.join([self.list_characters[randint(0, len(self.list_characters) - 1)]]))

            list_slov.append(''.join(list_bukv))

        return str(' '.join(list_slov))









    def setUp(self):
        #self.driver = webdriver.Chrome()

        self.driver = webdriver.Remote(command_executor='http://localhost:4444/wd/hub', desired_capabilities={
            "browserName": "chrome",
        })

        #self.driver.set_window_position(0, 0)  # устанавливает позицию левого вурзнего угла окна браузера
        self.driver.set_window_size(1440, 900)  # устанавливае мразмеры окна


        #self.driver.maximize_window()
        # self.driver.implicitly_wait(10) # для  явных ожиданий, будет вызываться перед каждвм методом find_element()

        self.list_characters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
                                'R', 'S',
                                'T', 'U', 'W', 'X', 'Y', 'Z',
                                'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'k', 'm', 'n', 'o', 'p', 'q',
                                'r', 's',
                                't', 'u', 'w', 'x', 'y', 'z',
                                '0', '1', '2', '3', '4', '5', '6', '7', '8', '9']  # поле

    def test_about_promouter(self):  # главный метод, надо чтобы он начинался  с test_

        driver = self.driver
        self.authorization(driver)  # вызов метода,котрый выше
        time.sleep(4)  # чтобы сразу окно не закрывалось

        # жме мна раздел Промотуреы
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH, "//a[@href='/superadmin/promoters']"))).click()

        time.sleep(2)

        list_of_promoters = WebDriverWait(driver, 10).until(
            ec.visibility_of_all_elements_located((By.XPATH, "//a[@class='ls-table-row-link ng-star-inserted']")))

        rand_index_of_promouter = randint(0, len(list_of_promoters)-1)

        list_of_promoters[rand_index_of_promouter].click() # кликаем на рондомного промотуреа
        time.sleep(2)

        # #  жме мна кионку редактиования Должность и Организация
        WebDriverWait(driver, 10).until(
            ec.visibility_of_all_elements_located((By.XPATH,"//button[@class='mat-icon-button mat-accent']")))[0].click()
        time.sleep(2)

        organisation_filed = WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Организация']")))

        organisation_filed.clear()
        time.sleep(1)

        organisation_filed.send_keys("странная организация")
        time.sleep(2)

        duty_field = WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Должность']")))

        duty_field.clear()
        time.sleep(1)
        duty_field.send_keys("Промоутер")

        # кнопка Сохранить
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH, "//button[@class='mat-raised-button mat-primary ng-star-inserted']"))).click()


        time.sleep(4)

        # жмем на  иконку редактирвоания поля Процент
        WebDriverWait(driver, 10).until(
            ec.visibility_of_all_elements_located((By.XPATH, "//button[@class='mat-icon-button mat-accent']")))[1].click()

        time.sleep(2)

        #поле Процент
        percentage_field = WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Процент']")))

        percentage_field.clear()
        time.sleep(2)

        percentage_field.send_keys(randint(2, 26))

        time.sleep(2)
        # кнопка Сохранить
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH, "//button[@class='mat-raised-button mat-primary ng-star-inserted']"))).click()

        time.sleep(2)

        # жмем на конку редактирвоания промокода
        WebDriverWait(driver, 10).until(
            ec.visibility_of_all_elements_located((By.XPATH, "//button[@class='mat-icon-button mat-accent']")))[2].click()

        time.sleep(2)
        promocode_fileld = WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Личный промокод']")))

        promocode_fileld.clear()
        promocode_fileld.send_keys(self.my_metho_randem_stroka(randint(4, 11), 1))
        time.sleep(2)

        # кнопка Сохранить
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable(
                (By.XPATH, "//button[@class='mat-raised-button mat-primary ng-star-inserted']"))).click()

        time.sleep(3)


        # #список вкладок
        # list_of_taps =  WebDriverWait(driver, 10).until(
        #     ec.presence_of_all_elements_located((By.XPATH, "//div[@role='tab']")))
        #
        # time.sleep(2)
        # for i in range(0, len(list_of_taps)):
        #     list_of_taps[i].click()
        #     time.sleep(2)
        #







    def tear_down(self):
            self.driver.quit()
            # pass

if __name__ == "__main__":
        unittest.main()


