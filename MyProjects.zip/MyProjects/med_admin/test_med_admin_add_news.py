# -*- coding: utf-8 -*-
import time
import unittest
import HtmlTestRunner #  для отчетов

import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains # lля сколддинга к нужному элементу импортируем класс ActionChains
from random import randint

import pytest
 # здесь  добавлени новости

class Admin_add_news(unittest.TestCase):


    def authorization(self, driver): # авторизация

        driver.get("https://admin.abm.technaxis.com/external/login")


        try:
            email_field = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Логин']" )))#
            email_field.send_keys("admin-abm@mail.ru")
        except :
            time.sleep(5)
            email_field.send_keys("admin-abm@mail.ru")

        try:
            password_field = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Пароль']" )))
            password_field.send_keys("password")
        except:
            time.sleep(5)
            password_field.send_keys("password")

        button_voity = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                                       "//button[@class='mat-raised-button mat-primary full-width ng-star-inserted']")))
        if button_voity.is_displayed():  # если кнпока видна , то
            button_voity.click()
            print("button is visible")

    @classmethod
    def setUp(cls):
        cls.driver = webdriver.Chrome()

        #self.driver.set_window_position(0, 0)  # устанавливает позицию левого вурзнего угла окна браузера
        cls.driver.set_window_size(1440, 900)  # устанавливае мразмеры окна


        #self.driver.maximize_window()
        # self.driver.implicitly_wait(10) # для  явных ожиданий, будет вызываться перед каждвм методом find_element()


    def test_method_admin_add_news(self):  # главный метод, надо чтобы он начинался  с test_

        driver = self.driver
        self.authorization(driver)  # вызов метода,котрый выше
        time.sleep(4)  # чтобы сразу окно не закрывалось

        # кнпока Добавть
        WebDriverWait(driver, 10).until(ec.element_to_be_clickable((By.XPATH, "//button[@class='abm-add-button mat-button mat-primary']"))).click()

        time.sleep(2)

        # на санцие  создания новости:
        # заголовок
        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='title']"))).send_keys("test test test test test tes")
        time.sleep(2)

        # описание
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='description']"))).send_keys(
            "test test test test test tes")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//div[@class='ql-editor ql-blank']"))).send_keys("test test test test test tes")

        time.sleep(2)

        file_dicitionary = {0: "/Users/rufina/Desktop/bunkets/2d1febbc8a2d4538dafb620c293749d2.jpg",
                            1: "/Users/rufina/Desktop/bunkets/08_big.jpg", 2: "/Users/rufina/Desktop/bunkets/9.jpg",
                            3: "/Users/rufina/Desktop/bunkets/96bfd35718e29bbd8f50e8fb2e1ee004.jpg",
                            4: "/Users/rufina/Desktop/bunkets/260_image_775x470_Energiya vkusa banketnyy zal 6.jpg",
                            5: "/Users/rufina/Desktop/bunkets/260_image_775x470_Energiya vkusa banketnyy zal 6.jpg",
                            6: "/Users/rufina/Desktop/bunkets/36866_1143.jpg",
                            7: "/Users/rufina/Desktop/bunkets/2875451.jpg", 8: "/Users/rufina/Desktop/bunkets/",
                            9: "/Users/rufina/Desktop/bunkets/23292.jpg",
                            10: "/Users/rufina/Desktop/bunkets/6599_ho_00_p_2048x1536.jpg",
                            11: "/Users/rufina/Desktop/bunkets/572a8b9f2385ae96e327146cb884118d.JPG",
                            12: "/Users/rufina/Desktop/bunkets/2875451.jpg",
                            13: "/Users/rufina/Desktop/bunkets/36866_1143.jpg",
                            14: "/Users/rufina/Desktop/bunkets/2875451.jpg",
                            15: "/Users/rufina/Desktop/bunkets/7081014_YRGu-QpsDK1Oi6yBuXp6j28YLCR210WS8tzyXjM_X9c.jpg",
                            16: "/Users/rufina/Desktop/bunkets/19693651325639393cb80ee.jpg",
                            17: "/Users/rufina/Desktop/bunkets/султанат2.jpg",
                            19: "/Users/rufina/Desktop/bunkets/a3b1.jpg", 20: "/Users/rufina/Desktop/bunkets/big_1.jpg",
                            21: "/Users/rufina/Desktop/bunkets/caption.jpg",
                            22: "/Users/rufina/Desktop/bunkets/Customized-Design-Printed-Carpet-for-Banquet-Hall-Hotel-Room.jpg",
                            23: "/Users/rufina/Desktop/bunkets/filef46175f6d7587cddba037b3fa3d90cd8.jpg",
                            24: "/Users/rufina/Desktop/bunkets/kriviera_16.jpg",
                            25: "/Users/rufina/Desktop/bunkets/maxresdefault (1).jpg"}

        foto = WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH,  "//input[@type='file']")))

        for i in range(0, randint(1, 10)):

            foto.send_keys(file_dicitionary[randint(0, len(file_dicitionary))])# берет рандомное фото и прикрепляет
            time.sleep(2)

        time.sleep(2)

        # тогглер
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH,  "//div[@class='mat-slide-toggle-thumb']"))).click()

        time.sleep(2)

        # кнпока Сохранить
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH,  "//button[@class='mat-flat-button mat-primary ng-star-inserted']"))).click()

        time.sleep(5)

    @classmethod
    def tear_down(cls):
        time.sleep(5)
        cls.driver.quit()
        # pass


if __name__ == "__main__":
    unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(
        output='/Users/rufina/PycharmProjects/MyProjects/med_admin/reports'))  # отчет об этом тесте сгенериться с папку reports




