# -*- coding: utf-8 -*-
import time
import unittest
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains # lля сколддинга к нужному элементу импортируем класс ActionChains
from random import randint

import pytest
 # здесь  заполнние заяки ДМС При ДТП

class fill_out_zayavka_dms_pri_dtp(unittest.TestCase):





    def setUp(self):
        self.driver = webdriver.Chrome()

        #self.driver.set_window_position(0, 0)  # устанавливает позицию левого вурзнего угла окна браузера
        self.driver.set_window_size(1440, 900)  # устанавливае мразмеры окна


        #self.driver.maximize_window()
        # self.driver.implicitly_wait(10) # для  явных ожиданий, будет вызываться перед каждвм методом find_element()


    def test_method_fill_out_dms_pri_dtp(self):  # главный метод, надо чтобы он начинался  с test_

        driver = self.driver
        #self.authorization(driver)  # вызов метода,котрый выше
        driver.get("https://med.abm.technaxis.com/main")

        time.sleep(4)  # чтобы сразу окно не закрывалось

        #пункт ДМС
        WebDriverWait(driver, 10).until(ec.presence_of_all_elements_located((By.XPATH, "//button[@class='abm-btn abm-main-nav-link abm-main-nav-dropdown nav-btn-arrow']")))[1].click()

        time.sleep(2)

        #  нажимаем ДМС при ДТП
        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//a[@href='/dms/dms-pri-dtp']"))).click()
        time.sleep(2)

        # кнпока Оформить онланй
        WebDriverWait(driver, 10).until(ec.element_to_be_clickable((By.XPATH, "//button[@class='abm-btn abm-btn-fill-white abm-btn-fill-white-full-width abm-btn-fill-white-high ripple']"))).click()


        time.sleep(2)
        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Фамилия']"))).send_keys("АНОФРИЕВА")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Имя']"))).send_keys("Инна")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Отчество']"))).send_keys("Юрьевна")

        time.sleep(2)
        # Пол
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//div[@class='select-value abm-grey-text']"))).click()

        time.sleep(2)

        # выбираем пол
        WebDriverWait(driver, 10).until(
            ec.presence_of_all_elements_located((By.XPATH, "//li[@class='select-option abm-purple-text med ripple']")))[
            1].click()
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Email']"))).send_keys("test@mail.ru")

        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Номер телефона']"))).send_keys("987654675439")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Дата рождения']"))).send_keys("12/09/1991")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Адрес регистрации']"))).send_keys("test test test")

        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Серия']"))).send_keys("6758")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Номер']"))).send_keys("567890")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Кем выдан']"))).send_keys("ОТДЕЛОМ уфмс")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Когда выдан']"))).send_keys("12/09/2001")
        time.sleep(2)



        # тогглер ( по умолчанию он включен)
        # переключаем тогглер  в состояние выкл, тогда появится кнопка Продолжить:
        WebDriverWait(driver, 10).until(
                ec.presence_of_element_located((By.XPATH, "//label[@class='abm-box-label-input-checkbox-swipe']"))).click()
        time.sleep(2)



        try: # попытается нажать на чекбоксы внизу , если они есть
            chechbox1 = WebDriverWait(driver, 10).until(
                ec.presence_of_all_elements_located((By.XPATH, "//label[@class='abm-box-label-input-checkbox']")))[0]


            if chechbox1.is_displayed() is False: # если чебкокс1 не отображен на странице, значит есть кнопка Продолжить
                print("chechbox1.is_displayed is False equal", chechbox1.is_displayed() is False)

                WebDriverWait(driver, 10).until( # жмем кнопку Продолжить
                ec.element_to_be_clickable((By.XPATH, "//button[@class='abm-btn abm-btn-fill abm-btn-fill-high abm-btn-fill-full-width ripple']"))).click()
                time.sleep(3)

                # следующая станица:
                # Фамилия
                WebDriverWait(driver, 10).until( #
                ec.presence_of_all_elements_located((By.XPATH, "//input[@formcontrolname='lastName']")))[1].send_keys("анофриев") # так ака поле Ывмилия уж етсь на предыдущей старнице

                time.sleep(2)

                #Имя
                WebDriverWait(driver, 10).until(  #
                    ec.presence_of_all_elements_located((By.XPATH, "//input[@formcontrolname='firstName']")))[
                    1].send_keys("олег")  # так ака поле   Имя уже ессь на предыдущей старнице

                time.sleep(2)

                WebDriverWait(driver, 10).until(  #
                    ec.presence_of_all_elements_located((By.XPATH, "//input[@formcontrolname='middleName']")))[
                    1].send_keys("юрьевич")  # так ака поле Ывмилия уж етсь на предыдущей старнице

                time.sleep(2)


                # Пол
                WebDriverWait(driver, 10).until(
                    ec.presence_of_element_located((By.XPATH, "//div[@class='select-value abm-grey-text']"))).click()

                time.sleep(2)

                # выбираем пол
                WebDriverWait(driver, 10).until(
                    ec.presence_of_all_elements_located(
                        (By.XPATH, "//li[@class='select-option abm-purple-text med ripple']")))[
                    1].click()
                time.sleep(2)

                WebDriverWait(driver, 10).until(  #
                    ec.presence_of_all_elements_located((By.XPATH, "//input[@formcontrolname='email']")))[
                    1].send_keys("test@mail.ru")  # так ака поле Ывмилия уж етсь на предыдущей старнице

                time.sleep(2)

                WebDriverWait(driver, 10).until(  #
                    ec.presence_of_all_elements_located((By.XPATH, "//input[@formcontrolname='phone']")))[
                    1].send_keys("89765432542")  # так ака поле Ывмилия уж етсь на предыдущей старнице

                time.sleep(2)

                WebDriverWait(driver, 10).until(  #
                    ec.presence_of_all_elements_located((By.XPATH, "//input[@formcontrolname='birthDate']")))[
                    1].send_keys("12/09/2005")  # так ака поле Ывмилия уж етсь на предыдущей старнице

                time.sleep(2)

                WebDriverWait(driver, 10).until(  #
                    ec.presence_of_all_elements_located((By.XPATH, "//input[@formcontrolname='address']")))[
                    1].send_keys("test test test test")  # так ака поле Ывмилия уж етсь на предыдущей старнице

                # Паспортные данные
                WebDriverWait(driver, 10).until(  #
                    ec.presence_of_all_elements_located((By.XPATH, "//input[@formcontrolname='series']")))[
                    1].send_keys("9087")  # так ака поле Ывмилия уж етсь на предыдущей старнице

                time.sleep(2)
                WebDriverWait(driver, 10).until(  #
                    ec.presence_of_all_elements_located((By.XPATH, "//input[@formcontrolname='number']")))[
                    1].send_keys("908798")  # так ака поле Ывмилия уж етсь на предыдущей старнице

                time.sleep(2)

                WebDriverWait(driver, 10).until(  #
                    ec.presence_of_all_elements_located((By.XPATH, "//input[@formcontrolname='whoIssued']")))[
                    1].send_keys("test tets tes tes tsdfghjs fsjdkhfs fkasfabskf")  # так ака поле Ывмилия уж етсь на предыдущей старнице

                time.sleep(2)

                WebDriverWait(driver, 10).until(  #
                    ec.presence_of_all_elements_located((By.XPATH, "//input[@formcontrolname='whenIssued']")))[
                    1].send_keys(
                    "19/09/2009")  # так ака поле Ывмилия уж етсь на предыдущей старнице

                time.sleep(2)

                WebDriverWait(driver, 10).until(
                    ec.presence_of_all_elements_located((By.XPATH, "//label[@class='abm-box-label-input-checkbox']")))[
                    0].click()
                time.sleep(2)

                WebDriverWait(driver, 10).until(
                    ec.presence_of_all_elements_located((By.XPATH, "//label[@class='abm-box-label-input-checkbox']")))[
                    1].click()

                time.sleep(2)

                #  Кнопка Оплатить
                WebDriverWait(driver, 10).until(
                    ec.presence_of_all_elements_located((By.XPATH,  "//button[@class='abm-btn abm-btn-fill abm-btn-fill-high abm-btn-fill-full-width ripple']"))).click()

                time.sleep(2)









            else: # жмем чекбоксы
                print("check chekboxes")
                time.sleep(2)
                chechbox1.click()
                time.sleep(2)

                WebDriverWait(driver, 10).until(
                    ec.presence_of_all_elements_located((By.XPATH, "//label[@class='abm-box-label-input-checkbox']")))[
                    1].click()
                time.sleep(2)

                #кнопка Отправить
                WebDriverWait(driver, 10).until(
                    ec.element_to_be_clickable((By.XPATH, "//button[@type='submit']"))).click()
                time.sleep(2)
        except:
            pass

        time.sleep(3)





    def tear_down(self):
        time.sleep(5)
        self.driver.quit()
        # pass


if __name__ == "__main__":
    unittest.main()

