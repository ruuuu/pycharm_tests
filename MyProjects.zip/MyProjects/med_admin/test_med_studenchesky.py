# -*- coding: utf-8 -*-
import time
import unittest
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains # lля сколддинга к нужному элементу импортируем класс ActionChains
from random import randint

import pytest
 # здесь  заполнние заяки Студенческий

class fill_out_zayavka_studenchesky(unittest.TestCase):





    def setUp(self):
        self.driver = webdriver.Chrome()

        #self.driver.set_window_position(0, 0)  # устанавливает позицию левого вурзнего угла окна браузера
        self.driver.set_window_size(1440, 900)  # устанавливае мразмеры окна


        #self.driver.maximize_window()
        # self.driver.implicitly_wait(10) # для  явных ожиданий, будет вызываться перед каждвм методом find_element()


    def test_method_fill_out_zayavka_studenchesky(self):  # главный метод, надо чтобы он начинался  с test_

        driver = self.driver
        #self.authorization(driver)  # вызов метода,котрый выше
        driver.get("https://med.abm.technaxis.com/main")

        time.sleep(4)  # чтобы сразу окно не закрывалось

        #Студенческий
        WebDriverWait(driver, 10).until(ec.presence_of_all_elements_located((By.XPATH, "//button[@class='abm-btn abm-main-nav-link abm-main-nav-dropdown nav-btn-arrow']")))[1].click()

        time.sleep(2)

        #  нажимаем на Студенчекий
        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//a[@href='/dms/studencheskij']"))).click()
        time.sleep(2)

        # кнпока Оформить онланй
        WebDriverWait(driver, 10).until(ec.element_to_be_clickable((By.XPATH, "//button[@class='abm-btn abm-btn-fill abm-btn-fill-full-width abm-btn-fill-high ru ripple']"))).click()


        time.sleep(2)
        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Фамилия']"))).send_keys("test")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Имя']"))).send_keys("test")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Отчество']"))).send_keys("test")

        time.sleep(2)
        # Пол
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//div[@class='select-value abm-grey-text']"))).click()

        time.sleep(2)

        # выбираем пол
        WebDriverWait(driver, 10).until(ec.presence_of_all_elements_located((By.XPATH, "//li[@class='select-option abm-purple-text med ripple']")))[1].click()
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Email']"))).send_keys("test@mail.ru")

        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Телефон']"))).send_keys("987654675439")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Дата рождения']"))).send_keys("12/09/2001")
        time.sleep(2)

        #  Гражданство
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH, "//div[@class='select-value abm-grey-text']"))).click()

        time.sleep(2)
        WebDriverWait(driver, 10).until(
             ec.presence_of_all_elements_located((By.XPATH,  "//li[@class='select-option abm-purple-text med ripple']")))[1].click()

        time.sleep(3)
        #кнопка Продолжить
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH, "//button[@type='submit']"))).click()
        time.sleep(5)

        #   след станица : "Паспортные данные"
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='series']"))).send_keys("1234")
        time.sleep(2)

        # Номер
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='number']"))).send_keys("12347986")
        time.sleep(2)



        # Кем выдан
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='whoIssued']"))).send_keys(
            "test test test")
        time.sleep(2)

        # когда выдан

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='whenIssued']"))).send_keys("14.06.2014")
        time.sleep(2)

        #Кнопка Продолжить
        WebDriverWait(driver, 10).until(
            ec.presence_of_all_elements_located((By.XPATH, "//button[@type='submit']")))[1].click()
        time.sleep(2)

        # Страница "Документ, подтверждающий право временного пребывания в РФ"
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "/html/body/app-root/app-layout/main/app-dms-student/div/app-block-form/div/div/div[2]/div[3]/app-form-step2/form/div[1]/div/div[1]/app-select-menu/div/div/div"))).click()
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH,  "//li[@class='select-option abm-purple-text med ripple']"))).click()
        time.sleep(3)


        # серия
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "/html/body/app-root/app-layout/main/app-dms-student/div/app-block-form/div/div/div[2]/div[3]/app-form-step2/form/div[1]/div/div[2]/label[1]/input"))).send_keys("9876")
        time.sleep(2)

        #  Номер
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "/html/body/app-root/app-layout/main/app-dms-student/div/app-block-form/div/div/div[2]/div[3]/app-form-step2/form/div[1]/div/div[2]/label[2]/input"))).send_keys("907854")
        time.sleep(2)

        # Кем выдан
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "/html/body/app-root/app-layout/main/app-dms-student/div/app-block-form/div/div/div[2]/div[3]/app-form-step2/form/div[1]/div/label[1]/input"))).send_keys(
            "test test test")
        time.sleep(2)

        # когда выдан
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "/html/body/app-root/app-layout/main/app-dms-student/div/app-block-form/div/div/div[2]/div[3]/app-form-step2/form/div[1]/div/label[2]/input"))).send_keys(
            "16.06.2011")
        time.sleep(2)

        # Адрес
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='address']"))).send_keys(
            "test test test")
        time.sleep(2)

        # город уч завдения
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='city']"))).send_keys(
            "test test test")
        time.sleep(2)

        # институт
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='institution']"))).send_keys(
            "test test test")
        time.sleep(2)

        # чекбоксы
        WebDriverWait(driver, 10).until(
            ec.presence_of_all_elements_located((By.XPATH,"//label[@class='abm-box-label-input-checkbox']")))[0].click()

        time.sleep(2)
        WebDriverWait(driver, 10).until(
            ec.presence_of_all_elements_located((By.XPATH, "//label[@class='abm-box-label-input-checkbox']")))[1].click()

        time.sleep(2)

        # кнопка Оформить
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH, "/html/body/app-root/app-layout/main/app-dms-student/div/app-block-form/div/div/div[2]/div[3]/app-form-step2/form/app-form-buttons-next-prev/div/button[1]"))).click()
        time.sleep(2)












    def tear_down(self):
        time.sleep(5)
        self.driver.quit()
        # pass


if __name__ == "__main__":
    unittest.main()

