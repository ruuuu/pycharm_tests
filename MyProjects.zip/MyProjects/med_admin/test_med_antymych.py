# -*- coding: utf-8 -*-
import time
import unittest
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains # lля сколддинга к нужному элементу импортируем класс ActionChains
from random import randint

import pytest
 # здесь  заполнние заяки Антимышь

class fill_out_zayavka_antymysh(unittest.TestCase):





    def setUp(self):
        self.driver = webdriver.Chrome()

        #self.driver.set_window_position(0, 0)  # устанавливает позицию левого вурзнего угла окна браузера
        self.driver.set_window_size(1440, 900)  # устанавливае мразмеры окна


        #self.driver.maximize_window()
        # self.driver.implicitly_wait(10) # для  явных ожиданий, будет вызываться перед каждвм методом find_element()


    def test_method_fill_out_zayavka_antymysh(self):  # главный метод, надо чтобы он начинался  с test_

        driver = self.driver
        #self.authorization(driver)  # вызов метода,котрый выше
        driver.get("https://med.abm.technaxis.com/main")

        time.sleep(5)  # чтобы сразу окно не закрывалось

        #пункт ДМС
        WebDriverWait(driver, 10).until(ec.presence_of_all_elements_located((By.XPATH, "//button[@class='abm-btn abm-main-nav-link abm-main-nav-dropdown nav-btn-arrow']")))[1].click()

        time.sleep(2)

        #  нажимаем Антимышь
        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//a[@href='/dms/strahovanie-vzroslyh-i-detej-ot-neschastnyh-sluchaev']"))).click()
        time.sleep(2)

        # кнпока Оформить онланй
        WebDriverWait(driver, 10).until(ec.element_to_be_clickable((By.XPATH, "//button[@class='abm-btn abm-btn-fill-white abm-btn-fill-white-full-width abm-btn-fill-white-high ripple']"))).click()


        time.sleep(2)
        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Фамилия']"))).send_keys("Анофиева")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Имя']"))).send_keys("Инна")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Отчество']"))).send_keys("Юрьевна")

        time.sleep(2)
        # Пол
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//app-select-menu[@formcontrolname='sex']"))).click()
        time.sleep(2)

        # выбираем пол
        WebDriverWait(driver, 10).until(
            ec.presence_of_all_elements_located((By.XPATH, "//li[@class='select-option abm-purple-text med ripple']")))[1].click()


        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Email']"))).send_keys("test@mail.ru")

        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Номер телефона']"))).send_keys("987654675439")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Дата рождения']"))).send_keys("12/09/1991")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Адрес регистрации']"))).send_keys("test test test")

        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Серия']"))).send_keys("6758")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Номер']"))).send_keys("567890")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Кем выдан']"))).send_keys("test test test")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Когда выдан']"))).send_keys("12/09/2001")
        time.sleep(2)



        # # тогглер
        #
        # WebDriverWait(driver, 10).until(
        #         ec.presence_of_element_located((By.XPATH, "//label[@class='abm-box-label-input-checkbox-swipe']"))).click()
        # time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_all_elements_located((By.XPATH, "//label[@class='abm-box-label-input-checkbox']")))[
            0].click()
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_all_elements_located((By.XPATH, "//label[@class='abm-box-label-input-checkbox']")))[
            1].click()
        time.sleep(2)

        #кнопка Отправить
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH, "//button[@type='submit']"))).click()
        time.sleep(2)


    def tear_down(self):
        time.sleep(5)
        self.driver.quit()
        # pass


if __name__ == "__main__":
    unittest.main()

