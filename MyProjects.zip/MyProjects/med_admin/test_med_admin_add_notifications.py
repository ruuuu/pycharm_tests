# -*- coding: utf-8 -*-
import time
import unittest
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains # lля сколддинга к нужному элементу импортируем класс ActionChains
from random import randint

import pytest
 # здесь  добавлени уведолмения

class Admin_add_notifications(unittest.TestCase):


    def authorization(self, driver): # авторизация

        driver.get("https://admin.abm.technaxis.com/external/login")


        try:
            email_field = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Логин']" )))#
            email_field.send_keys("admin-abm@mail.ru")
        except :
            time.sleep(5)
            email_field.send_keys("admin-abm@mail.ru")

        try:
            password_field = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Пароль']" )))
            password_field.send_keys("password")
        except:
            time.sleep(5)
            password_field.send_keys("password")

        button_voity = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                                       "//button[@class='mat-raised-button mat-primary full-width ng-star-inserted']")))
        if button_voity.is_displayed():  # если кнпока видна , то
            button_voity.click()
            print("button is visible")


    def setUp(self):
        self.driver = webdriver.Chrome()

        #self.driver.set_window_position(0, 0)  # устанавливает позицию левого вурзнего угла окна браузера
        self.driver.set_window_size(1440, 900)  # устанавливае мразмеры окна


        #self.driver.maximize_window()
        # self.driver.implicitly_wait(10) # для  явных ожиданий, будет вызываться перед каждвм методом find_element()


        


    def test_method_admin_add_notifications(self):  # главный метод, надо чтобы он начинался  с test_

        driver = self.driver
        self.authorization(driver)  # вызов метода,котрый выше
        time.sleep(4)  # чтобы сразу окно не закрывалось

        WebDriverWait(driver, 10).until(ec.element_to_be_clickable((By.XPATH, "//a[@href='/main/notifications']"))).click()
        time.sleep(2)


        # на санцие  создания уведолмения(раздел Email):
        # заголовок
        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='theme']"))).send_keys("test test test test test tes")
        time.sleep(2)


        # текст письма
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//div[@class='ql-editor ql-blank']"))).send_keys("test test test test test tes")

        time.sleep(2)

        # чекбокс
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//mat-checkbox[@formcontrolname='all']"))).click()
        time.sleep(2)

        # кнпока Отправить
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH,  "//button[@class='mat-flat-button mat-primary adm-text-uppercase ng-star-inserted']"))).click()

        time.sleep(2)
        # # в попапе жмем кноку Отменить
        # WebDriverWait(driver, 10).until(
        #     ec.element_to_be_clickable((By.XPATH, "//button[@class='mat-button mat-accent']"))).click()
        # time.sleep(2)

        # в попапе жмем кноку Отправмть
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH,
                                        "//button[@class='mat-flat-button mat-primary ng-star-inserted']"))).click()

        time.sleep(2)
        #раздел Личныф кабинет:

        WebDriverWait(driver, 10).until(
             ec.presence_of_all_elements_located((By.XPATH, "//div[@class='mat-tab-label mat-ripple ng-star-inserted']")))[1].click()

        time.sleep(2)
        # заголовок
        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@formcontrolname='theme']"))).send_keys("test test test test test tes")
        time.sleep(2)

        # текст уведолмения
        WebDriverWait(driver, 10).until(
             ec.presence_of_element_located((By.XPATH, "//div[@class='ql-editor ql-blank']"))).send_keys("test test test test test tes")
        #
        time.sleep(2)
        # чекбокс
        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//mat-checkbox[@formcontrolname='all']"))).click()
        time.sleep(2)

        #  кнпока Отправить
        WebDriverWait(driver, 10).until(
             ec.element_to_be_clickable((By.XPATH,  "//button[@class='mat-flat-button mat-primary adm-text-uppercase ng-star-inserted']"))).click()
        #
        time.sleep(2)
        #в попапе жмем кноку Отменить
        # # WebDriverWait(driver, 10).until(
        # #     ec.element_to_be_clickable((By.XPATH, "//button[@class='mat-button mat-accent']"))).click()
        # # time.sleep(2)
        #


        #  в попапе жмем кноку Отправмть
        WebDriverWait(driver, 10).until(
             ec.element_to_be_clickable((By.XPATH,
                                         "//button[@class='mat-flat-button mat-primary ng-star-inserted']"))).click()

        time.sleep(5)


    def tear_down(self):
        time.sleep(5)
        self.driver.quit()
        # pass


if __name__ == "__main__":
    unittest.main()



