# -*- coding: utf-8 -*-
import time
import unittest
import HtmlTestRunner #  для отчетов
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains # lля сколддинга к нужному элементу импортируем класс ActionChains
from random import randint

import pytest
 # здесь  заполнние заяки Трудовой мигрант

class fill_out_zayavka_trudovoy_migrant(unittest.TestCase):




    @classmethod
    def setUp(cls):
        cls.driver = webdriver.Chrome()

        #self.driver.set_window_position(0, 0)  # устанавливает позицию левого вурзнего угла окна браузера
        cls.driver.set_window_size(1440, 900)  # устанавливае мразмеры окна


        #self.driver.maximize_window()
        # self.driver.implicitly_wait(10) # для  явных ожиданий, будет вызываться перед каждвм методом find_element()


    def test_method_fill_out_trudovoy_migrant(self):  # главный метод, надо чтобы он начинался  с test_

        driver = self.driver
        #self.authorization(driver)  # вызов метода,котрый выше
        driver.get("https://med.abm.technaxis.com/main")

        time.sleep(4)  # чтобы сразу окно не закрывалось

        #пункт ДМС
        WebDriverWait(driver, 10).until(ec.presence_of_all_elements_located((By.XPATH, "//button[@class='abm-btn abm-main-nav-link abm-main-nav-dropdown nav-btn-arrow']")))[1].click()

        time.sleep(2)

        #  нажимаем Трудовой мигрант
        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//a[@href='/dms/meditsinskaya-strahovka-dlya-trudovyh-migrantov']"))).click()
        time.sleep(2)

        # кнпока Оформить онланй
        WebDriverWait(driver, 10).until(ec.element_to_be_clickable((By.XPATH, "//button[@class='abm-btn abm-btn-fill abm-btn-fill-full-width abm-btn-fill-high ripple']"))).click()


        time.sleep(2)
        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@placeholder='ФИО']"))).send_keys("test")
        time.sleep(2)

        WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Номер телефона']"))).send_keys("89098765676")
        time.sleep(2)


        # чекбокс
        WebDriverWait(driver, 10).until(ec.element_to_be_clickable((By.XPATH, "//label[@class='abm-box-label-input-checkbox']"))).click()
        time.sleep(2)

        #кнопка Отправить
        WebDriverWait(driver, 10).until(
            ec.element_to_be_clickable((By.XPATH, "//button[@class='abm-btn abm-btn-fill abm-btn-fill-high abm-btn-fill-full-width ripple']"))).click()
        time.sleep(2)

    @classmethod
    def tear_down(cls):
        time.sleep(5)
        cls.driver.quit()
        # pass


if __name__ == "__main__":
    unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(
        output='/Users/rufina/PycharmProjects/MyProjects/med_admin/reports'))  # отчет об этом тесте сгенериться с папку reports


