# -*- coding: utf-8 -*-
import time
import unittest
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait  # ожидания различных событий
from selenium.webdriver.support.ui import Select  # работа со списками
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains # lля сколддинга к нужному элементу импортируем класс ActionChains
from random import randint

import pytest
 # здесь  удалени и фильтрауия баннера

class Admin_delete_banner(unittest.TestCase):


    def authorization(self, driver): # авторизация

        driver.get("https://admin.abm.technaxis.com/external/login")


        try:
            email_field = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Логин']" )))#
            email_field.send_keys("admin-abm@mail.ru")
        except :
            time.sleep(5)
            email_field.send_keys("admin-abm@mail.ru")

        try:
            password_field = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//input[@placeholder='Пароль']" )))
            password_field.send_keys("password")
        except:
            time.sleep(5)
            password_field.send_keys("password")

        button_voity = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                                       "//button[@class='mat-raised-button mat-primary full-width ng-star-inserted']")))
        if button_voity.is_displayed():  # если кнпока видна , то
            button_voity.click()
            print("button is visible")


    def setUp(self):
        self.driver = webdriver.Chrome()

        #self.driver.set_window_position(0, 0)  # устанавливает позицию левого вурзнего угла окна браузера
        self.driver.set_window_size(1440, 900)  # устанавливае мразмеры окна


        #self.driver.maximize_window()
        # self.driver.implicitly_wait(10) # для  явных ожиданий, будет вызываться перед каждвм методом find_element()


    def filter_banners(self):

        list_of_tabs = WebDriverWait(self.driver, 10).until(ec.presence_of_all_elements_located((By.XPATH, "//div[@class='mat-tab-label mat-ripple ng-star-inserted']")))

        for i in range(0, len(list_of_tabs)): # перебираем все вкладки
            list_of_tabs[i].click()
            time.sleep(3)

        # кликаем на вкладку Все:
        all_tab = WebDriverWait(self.driver, 10).until(ec.presence_of_all_elements_located(
            (By.XPATH, "//div[@class='mat-tab-label mat-ripple ng-star-inserted']")))[0]
        all_tab.click()
        time.sleep(2)

        # фильрация по Название
        for i in range(0, 3):
            WebDriverWait(self.driver, 10).until(ec.element_to_be_clickable((By.XPATH,  "//button[@aria-label='Change sorting for title']"))).click()
            time.sleep(2)

        # фильрация по Дата
        for i in range(0, 3):
            WebDriverWait(self.driver, 10).until(
                ec.element_to_be_clickable((By.XPATH, "//button[@aria-label='Change sorting for dateMs']"))).click()
            time.sleep(2)

        all_tab.click()


    def delete_banner(self):

        #  список кнопок Удалить
        delete_buttons = WebDriverWait(self.driver, 10).until(
            ec.presence_of_all_elements_located((By.XPATH, "//button[@class='mat-button mat-warn']")))

        # берем рандомную кнпоку и удлаляем
        rand_index_of_delete_button = randint(0, len(delete_buttons))
        print("random of  firset ledete button", rand_index_of_delete_button)

        delete_buttons[rand_index_of_delete_button].click()  # кликаем рандомную кнокпку Удалить
        time.sleep(2)

        #  в попапе жмем кнопку Отменить
        WebDriverWait(self.driver, 10).until(
            ec.element_to_be_clickable((By.XPATH, "//button[@class='mat-button mat-accent']"))).click()
        time.sleep(4)

        #  снова жмем  рандомную кноку Удалить

        # берем рандомную кнпоку и удлаляем
        rand_index_of_delete_button = randint(0, len(delete_buttons)-1)

        print("random of  second  ledete button", rand_index_of_delete_button)
        delete_buttons[rand_index_of_delete_button].click()  # кликаем рандомную кнокпку Удалить
        time.sleep(2)

        #  в поапе кликаме Удалить
        WebDriverWait(self.driver, 10).until(ec.element_to_be_clickable(
            (By.XPATH, "//button[@class='mat-flat-button mat-primary ng-star-inserted']"))).click()
        time.sleep(2)



    def search_banners(self):

        for i in range(0, randint(2, 5)):

            # спсико названий баннеров
            list_of_title = WebDriverWait(self.driver, 10).until(ec.presence_of_all_elements_located(
                (By.XPATH, "//mat-cell[@class='mat-cell cdk-column-title mat-column-title ng-star-inserted']")))

            time.sleep(3)
            # поле поиска
            rand_index_of_title = randint(0, len(list_of_title) - 1)
            WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                            "//input[@placeholder='Поиск']"))).send_keys(list_of_title[rand_index_of_title].text)
            print("list_of_title[rand_index_of_title].text equal on", i, "itearation", list_of_title[rand_index_of_title].text)
            time.sleep(3)
            WebDriverWait(self.driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                                 "//input[@placeholder='Поиск']"))).clear()
            time.sleep(3)

            self.driver.refresh() # обновяет страницу

        time.sleep(2)



    def test_method_admin_delete_banners(self):  # главный метод, надо чтобы он начинался  с test_

        driver = self.driver
        self.authorization(driver)  # вызов метода,котрый выше
        time.sleep(4)  # чтобы сразу окно не закрывалось

        WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH, "//a[@href='/main/banners']"))).click()
        time.sleep(2)



        self.filter_banners() # вызоа метода фильрации баннеров
        time.sleep(2)

        self.search_banners()# вызоа метода поиска баннеров
        time.sleep(2)


        self.delete_banner()# вызов метода удаления баннера




    def tear_down(self):
        time.sleep(3)
        self.driver.quit()
        # pass


if __name__ == "__main__":
    unittest.main()



